# AGENTS.md

Overleaf-synced LaTeX manuscript (no application code): the DD-Mamba paper, an Elsevier *Neurocomputing* submission built on `elsarticle.cls`. The git remote is `git.overleaf.com`, so any push lands directly in the Overleaf project. Commit history is Overleaf auto-syncs; do not commit or push unless asked.

## Repository layout

- `main.tex` — preamble, macros, frontmatter (title/abstract/keywords), the ordered `\input`s, back-matter declarations (CRediT, competing interest, Funding, Acknowledgements, generative-AI declaration, Data availability; ordered per the 40-paper Neurocomputing corpus in `assets/neurocom-spec.md` §6.1), and the bibliography. ~110 lines; body text lives in the section files.
- `1_Intro.tex`, `2_RelatedWork.tex`, `4_Method.tex`, `5_Experiments.tex`, `7_Conclusion.tex` — the five numbered section files, `\input` from `main.tex` in order (m2patch-style split; `4` is `Method`). The `\section{Preliminaries}` block (formerly `3_Preliminary.tex`) now sits at the top of `4_Method.tex`, before `\section{Method}`; the `\section{Discussion}` block (formerly `6_Discussion.tex`) now sits at the top of `7_Conclusion.tex`, before `\section{Conclusion}`. `5_Experiments.tex` is by far the largest: it holds the figures and the `\input{tables/...}` calls. Its subsection order is Experimental details → Main Results → Component analysis → Robustness analysis → Hyperparameter sensitivity → Case study → Matched training efficiency. Keep the numbered-filename convention when adding or renaming sections.
- The Robustness analysis subsection reports a test-time Gaussian-noise sweep on ETTh2 (σ ∈ {0.1, 0.2, 0.3, 0.5} plus clean anchor, H ∈ {96, 192, 336, 720}, single seed 2023; training/validation clean, targets never corrupted). Its figure is `figures/robustness.pdf`, converted losslessly from the RGBA PNG exported by the Pamba-style notebook in `references/robustness_results/` (data + plotting mechanism) with scripts under `references/dd-mamba/scripts/robustness/`; Weather sweep data also exists there but is deliberately not reported in the manuscript. Design rationale and full protocol: `assets/robustness.md`.
- `tables/` — table bodies `\input` from `5_Experiments.tex`: `table_datasets.tex`, `table_horizons_ett.tex`, `table_horizons_general.tex`, `table_pems.tex`, `table_core_ablation_main.tex`, `table_training_efficiency.tex`. Each `\input{tables/...}` call in `5_Experiments.tex` is preceded by a multi-line comment block naming the table and its label, so keep that comment style when adding tables.
- All figure PDFs live in `figures/` (referenced as `figures/<name>.pdf`); there is no figure at the repo root.
- `refs.bib` — the bibliography (`\bibliography{refs}`). The root `neurocom.bib` is an unused earlier snapshot referenced by no `.tex` file — never edit it expecting PDF changes.
- `highlights.tex` (root) + `assets/highlights.pdf` — Neurocomputing highlights document.
- `assets/` — supporting docs: `neurocom-spec.md` (distilled venue spec; full source in `neurocom-guide.md`), `robustness.md` (robustness-sweep design rationale), `edition.md` (simulated five-seat review report with a P0/P1/P2 revision roadmap — prune resolved items from it as the manuscript evolves).
- `elsarticle.cls`, `elsarticle-num.bst` — document class and (locally patched) bibliography style.
- Git-ignored, local only: `build/`, `references/`, `citation/`, `.opencode/`, `.vscode`, `assets/prompt.txt`. `references/` holds three trees: `dd-mamba/` (the official code repo — it has **its own `AGENTS.md`** with run/provenance discipline, e.g. "an expected value is not a result"), `m2patch_manuscript/` (the reference manuscript the section-split architecture follows), and `robustness_results/` (robustness sweep data + plotting notebook).

## Build & Validation

```bash
# Full build — required after any \cite key change or refs.bib edit
pdflatex -output-directory=build main.tex && bibtex build/main && pdflatex -output-directory=build main.tex && pdflatex -output-directory=build main.tex

# Quick compile — text-only edits (section files included via \input)
pdflatex -output-directory=build main.tex
```

Gotchas:

- `build/` does not exist in the repo and `pdflatex -output-directory=build` fails silently — create it first: `New-Item -ItemType Directory build`.
- `bibtex` reads `build/main.aux`, hence `bibtex build/main` (not `bibtex main`). Its volume/number warnings are benign.
- After compiling, scan `build/main.log` for `Citation ... undefined` / `Reference ... undefined` (run the full build to fix) and `!` error lines.
- **natbib is loaded by `elsarticle.cls` itself** — never add `\usepackage{natbib}` (option clash).
- To verify that a refactor (e.g. moving text between files) leaves the PDF unchanged, PDF hashes are not comparable across normal builds because pdftex embeds timestamps. Set `$env:SOURCE_DATE_EPOCH='946684800'` before each `pdflatex` run — the output becomes byte-identical and SHA-256 comparison is meaningful.

## Codegraph

- The repo keeps a CodeGraph index (`.codegraph/`). Use codegraph mcp for content searching.
- **Run `codegraph sync` as the final step of every file-modification task** so the index stays consistent for subsequent queries.

## PDF retrieval (academic-kb MCP)

- Literature retrieval runs through the remote `academic-kb` MCP service (`https://academic.xschen.com/mcp`, Streamable-HTTP + static Bearer token; configured globally in opencode and Codex). It supersedes the deprecated local `citation-rag` deployment (Docker, 127.0.0.1:8802) — that stack is no longer maintained.
- Corpus tools (no LLM cost), registered as `academic-kb_<tool>`: `corpus_overview` (groups + index coverage), `search_corpus` (page-level semantic search; `groups` filter such as `["NeuroCom","TNNLS"]`, `top_k=8`), `read_pdf_pages` (read 3–5 hit pages, `"1-3,5"` syntax), `search_pdf`, `pdf_info`, `corpus_warm` (build/refresh page indexes after new uploads; incremental, idempotent). `rel_path` (`组名/文件名.pdf`, e.g. `NeuroCom/...pdf`) is the document handle returned by search/overview — never fabricate it.
- Paper-library tools (LLM quota or slower): `search_papers`/`summarize_paper` cover only KB-ingested papers; `generate_background`, `generate_revision_suggestions`, `analyze_gaps`, `ingest_papers` consume LLM quota — announce cost/duration before calling; `search_online`/`discover_related` hit arXiv/Crossref/Semantic Scholar; `export_bibtex` exports `.bib` (never hand-copy entries).
- When a writing task needs ground truth from these papers, retrieve via these tools — never read whole PDFs into context. Workflow: `corpus_overview` → `search_corpus` (2–3 query phrasings, targeted groups) → `read_pdf_pages` on the hit pages → cite provenance as `[Group/Doc p.N]`.
- See the user-level `academic-kb` skill (opencode/Codex) for the tool-selection decision table and workflow recipes.

## Language

- OpenCode CLI output (explanations, progress, decision points): **Simplified Chinese**.
- Markdown documentation (e.g. `README.md`): **Simplified Chinese**.
- Everything else (LaTeX sources, configs, code comments): **English**.

## Conventions & constraints

- Document class is `[final,5p,times,twocolumn]{elsarticle}` — `figure*` / `table*` are real two-column floats; keep the existing `[tb]`/`[tbp]` float specifiers.
- **Use the macros defined in `main.tex`**: `\model{}` for the model name (never hardcode "DD-Mamba" in text), `\best{}` (bold, red) and `\second{}` (underlined, purple) for best/second-best results in tables — the S-Mamba highlighting convention. TikZ figures share the muted color palette defined in the preamble.
- **`elsarticle-num.bst` is locally patched**: `write.url` is stubbed out so printed URLs are suppressed while DOI hyperlinks remain. Do not replace it with the stock Elsevier file. BibTeX `empty pages` warnings for ICLR and page-less proceedings entries are known and accepted — never invent page numbers.
- **Neurocomputing style**: tables use no vertical rules and no cell shading, with notes below the tabular; highlights file has 3–5 bullets of ≤85 chars each; abstract <250 words; exactly 5 keywords.
