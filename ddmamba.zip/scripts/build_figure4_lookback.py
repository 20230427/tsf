#!/usr/bin/env python3
"""Build the two-panel ECL lookback comparison used as Figure 4.

Both panels use selected-checkpoint validation metrics from the same audited
Electricity lookback archive.  Test metrics are deliberately ignored.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


MODELS = (
    ("dual_domain", "DD-Mamba", "#C43B3B", "o"),
    ("smamba", "S-Mamba", "#2C6FBB", "s"),
    ("itransformer", "iTransformer", "#2A9D8F", "^"),
    ("patchtst", "PatchTST", "#E07B39", "D"),
    ("crossformer", "Crossformer", "#7A5AA6", "v"),
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_inputs(summary_path: Path) -> dict:
    summary = json.loads(summary_path.read_text(encoding="utf-8"))

    if summary.get("analysis_schema") != "ddmamba-lookback-analysis-v1":
        raise ValueError("Unsupported lookback summary schema")
    if summary.get("dataset", "").lower() not in {"electricity", "ecl"}:
        raise ValueError("Lookback summary must contain Electricity/ECL data")
    if summary.get("horizon") != 96 or not summary.get("complete"):
        raise ValueError("Lookback summary must be complete and use H=96")
    lengths = [int(value) for value in summary["lengths"]]

    curves: dict[str, dict] = {}
    for key, label, color, marker in MODELS:
        if key not in summary["models"]:
            raise ValueError(f"Missing selected model: {key}")
        mse_values = []
        mae_values = []
        for length in lengths:
            runs = summary["cells"][str(length)][key]["runs"]
            if len(runs) != 1:
                raise ValueError(
                    f"Figure 4 expects one audited run for {key} at L={length}"
                )
            metrics = runs[0].get("best_val_metrics", {})
            mse = metrics.get("mse")
            mae = metrics.get("mae")
            if not isinstance(mse, (int, float)) or not isinstance(mae, (int, float)):
                raise ValueError(f"Missing validation metrics for {key} at L={length}")
            mse_values.append(float(mse))
            mae_values.append(float(mae))
        curves[key] = {
            "label": label,
            "color": color,
            "marker": marker,
            "validation_mse": mse_values,
            "validation_mae": mae_values,
        }

    return {
        "schema": "ddmamba-figure4-lookback-v1",
        "dataset": "ECL / Electricity",
        "horizon": 96,
        "metric_scope": "selected-checkpoint validation metrics",
        "seed_values": summary["seed_values"],
        "lookbacks": lengths,
        "models": curves,
        "sources": {
            "lookback_summary": {
                "path": summary_path.name,
                "sha256": sha256(summary_path),
            }
        },
        "notes": [
            "Only best-checkpoint validation MSE and MAE are plotted; test metrics are excluded",
            "All model curves are single-seed results (seed 2024)",
        ],
    }


def plot(data: dict, out_prefix: Path, pdf_path: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    grid = "#D6DFEB"
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.titlesize": 11,
            "axes.linewidth": 0.8,
            "pdf.fonttype": 42,
            "svg.fonttype": "none",
        }
    )

    fig, (left, right) = plt.subplots(1, 2, figsize=(13.8, 4.45))
    for axis in (left, right):
        axis.grid(True, color=grid, ls="--", lw=0.6, alpha=0.85)
        axis.set_axisbelow(True)

    x_values = data["lookbacks"]

    def metric_panel(axis, metric: str, title: str, ylabel: str) -> None:
        for key, curve in data["models"].items():
            is_main = key == "dual_domain"
            axis.plot(
                x_values,
                curve[metric],
                color=curve["color"],
                marker=curve["marker"],
                ms=4.8 if is_main else 4.0,
                lw=2.2 if is_main else 1.35,
                label=curve["label"],
                zorder=5 if is_main else 3,
            )
        axis.axvline(96, color="#737E8C", ls=":", lw=1.0, zorder=1)
        axis.set_title(title)
        axis.set_xlabel("Lookback length L (hourly steps)")
        axis.set_ylabel(ylabel)
        axis.set_xticks(x_values, labels=[str(value) for value in x_values], rotation=90)
        axis.tick_params(axis="x", labelsize=8.5)
        axis.margins(x=0.035)

    metric_panel(
        left,
        "validation_mse",
        "(a) Validation MSE versus lookback",
        "Selected-checkpoint validation MSE",
    )
    metric_panel(
        right,
        "validation_mae",
        "(b) Validation MAE versus lookback",
        "Selected-checkpoint validation MAE",
    )
    left.legend(
        frameon=False,
        fontsize=8.7,
        ncol=2,
        columnspacing=1.1,
        handlelength=2.3,
        loc="upper right",
    )

    fig.suptitle("Lookback analysis | ECL | H=96", fontsize=13)
    fig.text(
        0.5,
        0.012,
        "Validation-only selected-checkpoint metrics | Single seed: no uncertainty bars",
        ha="center",
        fontsize=9.5,
        color="#606B76",
    )
    fig.tight_layout(rect=(0.008, 0.065, 0.992, 0.92), w_pad=3.2)

    out_prefix.parent.mkdir(parents=True, exist_ok=True)
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_prefix.with_suffix(".png"), dpi=300, facecolor="white")
    fig.savefig(out_prefix.with_suffix(".svg"), facecolor="white")
    fig.savefig(pdf_path, facecolor="white")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--out-prefix", type=Path, required=True)
    parser.add_argument("--pdf-path", type=Path, required=True)
    args = parser.parse_args()

    data = load_inputs(args.summary)
    data["plot_script_sha256"] = sha256(Path(__file__))
    plot(data, args.out_prefix, args.pdf_path)
    args.out_prefix.with_suffix(".json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({"pdf": str(args.pdf_path), "models": len(MODELS)}, indent=2))


if __name__ == "__main__":
    main()
