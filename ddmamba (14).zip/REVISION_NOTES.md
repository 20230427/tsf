# DD-Mamba revision notes

This directory is a revised copy of `C:\Users\wcg18\Desktop\main\tmp\ddmamba9_review`. The source directory was not edited.

## Implemented changes

1. Corrected the claim that every benchmark uses a causal Mamba temporal encoder. The revised paper distinguishes causal-Mamba recipes from the MLP temporal encoders used by ECL, Traffic, and PEMS03/04/07/08.
2. Reframed the temporal contribution as a decomposition-based linear anchor with a zero-initialized learned correction, which is the invariant design across reported configurations.
3. Expanded the frequency method to state the dense complex-linear real/imaginary mapping explicitly and separated the common spectral encoder from the optional FITS-style anchor used only by ETTh1, ETTh2, and Weather.
4. Added the initialization contract: zero-initialized temporal correction, conditional frequency initialization, and the time-dominant gate initialization with bias 2.2.
5. Initially documented the dataset-specific temporal encoder, spectral anchor, mixer placement, and RevIN recipes in Table 2; the table was removed in v4 at the author's request.
6. Added the shared-mixer implementation detail for high-channel datasets and limited its claim to parameter-efficient cross-variable modeling rather than universal accuracy improvement.
7. Replaced `white-box` language with `forecast-decomposable` or `structurally inspectable` language.
8. Bounded component claims to dataset-specific effects and disclosed the legacy provenance limitation alongside the matched statistics.
9. Rebuilt `highlights.pdf` from the revised `highlights.tex`, removing the earlier source/PDF mismatch.
10. Updated the AI-assisted preparation statement to disclose the use of OpenAI Codex for consistency checks and language editing.

## Staircase and efficiency integration

11. Added a paper-styled, validation-only Weather capacity staircase covering lookback, model width, learning rate, training time, peak memory, and parameter count.
12. Replaced the earlier post-hoc test-set sensitivity figure and discussion with the validation-only staircase; the manuscript retains the current benchmark configuration and treats width 64 only as a compact confirmatory candidate.
13. Added a paper-styled cumulative step-down heatmap covering eleven datasets and relabelled the terminal state as the time-only recipe because high-channel configurations use a temporal MLP. In v5, the heatmap was converted to a source-data-derived table at the author's request.
14. Explicitly distinguished cumulative recipe states from one-change-at-a-time marginal ablations, marked structural no-ops, and limited the new matrix to descriptive single-seed evidence.
15. Retained the existing matched efficiency figure and six-seed component table because they answer different questions from the new capacity and cumulative analyses.
16. Added `documents/NEW_STAIRCASE_EFFICIENCY_COMPARISON.md` to the project root with source inventory, numerical comparison, provenance limits, and integration decisions.
17. Condensed the two newly added experiment sections to match the reference-paper style: the main text now emphasizes trends, interpretation, and evidence limits, while exact settings remain visible in the figures and underlying project records.
18. Removed the dataset-specific recipe table from Section 4 and deleted its introductory paragraph and source file; the remaining tables are renumbered automatically.
19. Replaced the former Figure 3 with a three-line cumulative step-down table. All 66 original annotations match the source JSON; the new table adds the same-run Full MSE reference and displays relative changes to one decimal place. It retains structural no-ops and single-seed descriptive limits. The immutable source snapshot, numeric exports, validation report, and table builder are included.

## Figure 4 replacement (ECL)

- Replaced the Weather capacity staircase with the supplied complete ECL validation study at horizon 96.
- Updated the Figure 4 caption, experimental interpretation, discussion, conclusion, and limitations to match the ECL lookback, resource, width, and learning-rate panels.
- Explicitly identifies the new evidence as single-seed and descriptive, with no standard-deviation error bars or benchmark-configuration change.

## Table 1 dataset coverage

- Added PEMS03, PEMS04, PEMS07, and PEMS08 to the dataset-characteristics table.
- Reported their sensor counts, total timesteps, and 5-minute sampling granularity consistently with the project dataset inventory and PEMS configurations.
- Removed the separator rule before the PEMS rows so every dataset row uses the same visual treatment and text formatting.

## Terminology cleanup

- Removed the unsupported phrase ``compact inferential table'' from the threats-to-validity discussion while retaining the documented inferential-family and efficiency-comparison scope.

## Descriptive-claim and discussion revision

- Recast the matched baseline findings as descriptive and removed the three strong Benjamini--Hochberg significance claims from the abstract, main-results discussion, and conclusion.
- Corrected ``Early fusion'' to prediction-level mean fusion and replaced ``phase-preserving'' with the technically bounded statement that the complex-linear encoder retains real--imaginary coupling.
- Identified Illness as an auxiliary cumulative-analysis diagnostic rather than part of the main benchmark set.
- Added a module-level and recipe-oriented Related Work paragraph covering TimeRecipe and CombinationTS.
- Condensed the Discussion and threats-to-validity text while preserving the principal negative results and study limitations.

## Deliberately not added

- No new experimental results, citations, checkpoints, or statistical claims were fabricated.
- The 97.9% off-diagonal spectral-energy value and the reported mean gate value were not inserted because no immutable checkpoint/configuration artifact in the reviewed workspace reproduces them.
- No author names, affiliations, ORCIDs, acknowledgements, or repository-release statements were invented.
- The architecture figure is retained from the source package. Its revised caption identifies the displayed causal-Mamba block as one instantiation and notes the high-channel MLP configuration directly.

## Remaining author actions before submission

1. Replace author, affiliation, email, and CRediT placeholders with verified information.
2. Complete or remove the acknowledgements placeholder.
3. Generate provenance-complete main-result artifacts with resolved configurations, configuration hashes, commit identifiers, and seed-level records.
4. If stronger mechanism claims are desired, add reproducible gate-distribution, spectral-mixing, and branch-decomposition analyses tied to checkpoint hashes.
5. Confirm the final data/code availability statement and submission repository location.

## Build verification

- Build command: `pdflatex main.tex`, `bibtex main`, `pdflatex main.tex` twice.
- Final manuscript: 14 pages.
- LaTeX errors: 0.
- Undefined citations/references: 0.
- Overfull boxes: 0.
- All 14 rendered v5 manuscript pages, including the new cumulative table and renumbered figures/tables, were visually inspected. The unchanged highlights document is retained from v4.
