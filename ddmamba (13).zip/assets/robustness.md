# DD-Mamba Robustness 实验设计方案

> 状态：设计文档（待执行）。基于 Neurocomputing 40 篇语料（`D:\repository\citation-rag\corpus\NeuroCom`，经 pdf-mcp 检索）与 `assets/neurocom-spec.md` §3.5 的期刊规范统计，为当前 manuscript 制定 Robustness 实验的完整设计、执行与 LaTeX 集成方案，供后续 coding agent 直接执行。
>
> 检索时间：2026-08-24；服务：`citation-rag-pdf-mcp` v2.2.1（healthy）。

---

## 0. 结论摘要（TL;DR）

1. **当前论文没有任何 robustness 实验**（全文唯一 "robust" 出现在 `1_Intro.tex:5` 描述 DLinear/RLinear 的句子；`5_Experiments.tex` 六个小节均无 robustness 内容）。而 Neurocomputing 语料中 **30/40** 的论文包含 Robustness 实验（neurocom-spec.md §3.5），这是标准实验电池中的一个**明确缺口**。
2. Neurocomputing 的主流设计是**两类污染**：加性高斯噪声注入 + 随机缺失（点掩码），个别论文加异常值注入。参数化在 σ ∈ {0.1, 0.2, 0.3}（TF4TF）、SNR dB（EIAformer/DFCon）、相对幅度 ε%（Waveformer）、污染比例 r（ST-DAGCN/MSF-GODE）之间变化。
3. **推荐 DD-Mamba 采用 test-time corruption 协议**：训练好的 checkpoint 不变，仅在测试集输入窗口上注入污染（ST-DAGCN / MSF-GODE / EIAformer 模式）。优点：(a) 纯推理，预算极小；(b) 与论文 "test split was not used for any configuration decision" 的合规原则一致；(c) 可复用 matched five-seed rerun 的 7 个 in-pipeline baseline checkpoint 做跨模型对比（EIAformer/MSF-GODE 式），比 TF4TF 式 self-only 表更强。
4. 核心交付：**一张跨模型表**（DD-Mamba + 代表性 baselines × Clean/污染水平，MSE/MAE + 相对退化）+ **一张自稳健表或退化曲线图**（可选），以 `\subsection{Robustness analysis}` 插入 `5_Experiments.tex` 的 Hyperparameter sensitivity 与 Case study 之间。

---

## 1. 服务与语料检索记录

- pdf-mcp 服务验证：容器 `citation-rag-pdf-mcp` healthy（127.0.0.1:8802→8000），`server_info` 正常返回（hybrid search 可用，corpus 上限 100 文件/调用）。
- 检索式（`pdf_corpus_search`，`/data/pdfs/NeuroCom`，hybrid BM25+语义）：
  - `"robustness missing values noise perturbation experiments"`
  - `"corrupted data anomaly injection robustness evaluation forecasting"`
- 命中后用 `pdf_read_pages` 精读命中页（仅命中页，未整本读入）。下表所有细节均来自命中页原文。

---

## 2. Neurocomputing 语料中的 Robustness 实验设计证据

### 2.1 逐篇深读结果

| 论文（刊期/编号） | 节位置 | 污染类型与公式 | 水平 | 污染位置 | 对比范围 | 呈现方式 |
|---|---|---|---|---|---|---|
| **ST-DAGCN**, Neurocomputing 601 (2024) 128175 | §4.4.3 Robustness analysis | 缺失：$\tilde X = X \odot M$；噪声：$\tilde X = X + M \odot \hat\delta$，$\hat\delta = (\max-\min)\cdot\delta\cdot k$，$\delta\sim\mathcal N(0,1)$，$k$ 为严重度 | 比例 $r \in \{0.02,\dots,0.1\}$，步长 0.02 | **仅测试集** | 仅自身 | 折线图（Fig. 9，x=污染比例，y=指标），无表 |
| **TF4TF**, Neurocomputing 617 (2025) 128913 | §4.7（4.7.1 噪声注入 / 4.7.2 异常注入） | 噪声：训练数据输入序列加 $\sigma$ 高斯；异常：随机选 3% 时间点做 $[-2x_i, 2x_i]$ 内随机尺度变换，再按比例 $\epsilon$ 选样本 | $\sigma\in\{0.1,0.2,0.3\}$；$\epsilon\in\{30\%,50\%,80\%\}$ | **训练集（重训）** | 仅自身 | 表 11/12：ETTh1+ETTh2 × H∈{96,192,336,720}，"Original" 锚定行，MSE/MAE |
| **Waveformer**, Neurocomputing 650 (2025) 130923 | §4.10 噪声敏感度 | 乘性相对均匀噪声：$[-\varepsilon X_t, +\varepsilon X_t]$ | $\varepsilon\in\{1\%,5\%,10\%\}$ | 输入序列（测试评估） | 仅自身 | 表 9：MSE/MAE，覆盖测试集与多个预测长度 |
| **EIAformer**, Neurocomputing 658 (2025) 131700 | §4.10 Robustness analysis | 零均值高斯，按信噪比定标（dB，越低越强） | SNR ∈ {30, 20, 10} dB + **Clean 列** | 注入所选数据集（测试评估） | **vs baselines**（Autoformer, PatchTST, FEDformer） | 表 14：ETTh2, L=96→H=96, MSE；叙述用"退化速率显著更慢" |
| **DFCon**, Neurocomputing 656 (2025) 131418 | §5.9 Noise robustness and efficiency | 高斯噪声注入特征向量，SNR 定标 | {无噪声, 10 dB, 20 dB} | 特征/输入（测试评估） | 仅自身 | 表 8：ETTh2+Electricity, H=1440, MSE/MAE |
| **MSF-GODE**, Neurocomputing 658 (2025) 131566 | §5.9 Model robustness testing | (1) 零均值高方差高斯按比例 $\rho_n=20\%$；(2) **块状（时空连续）缺失** $r=30\%$ | 各一个固定水平 | **仅测试集** | vs 变体+baseline（DSTTN 等） | 表 12 + Fig. 12 柱状图：10 次重复 mean±std，配对 t 检验标星（*p<0.01, **p<0.05, ***p<0.001）；**所有模型共用同一套 mask 与噪声样本** |
| **Q-WaveMixer**, Neurocomputing 701 (2026) 134567 | §5.3（量子噪声） | 退极化噪声概率 $p$ 扫描 | $p \in (0, 0.1]$ | 推理路径 | vs 纯量子变体 + DLinear 参考线 | Fig. 4 折线：x=$p$, y=MSE；叙述强调"graceful degradation"（平滑退化到线性基线） |

### 2.2 提炼出的共性模式（设计规律）

1. **节位置与命名**：Experiments 靠后处、独立小节，命名 `Robustness analysis` / `Model robustness testing` / `Noise robustness`；通常在 ablation / sensitivity 之后、efficiency 或 interpretability 附近。
2. **两类标准污染**：加性高斯噪声（几乎所有论文）+ 缺失/掩码（ST-DAGCN、MSF-GODE）；异常值注入是 TF4TF 特有的第三类。噪声水平一律 2–3 档，含 clean/original 锚定。
3. **污染位置两派**：test-time-only（ST-DAGCN、MSF-GODE、EIAformer——便宜、可控、可与基线公平共享同一套扰动）vs train-time 污染后重训（TF4TF——贵，需 levels×datasets×models 次重训）。
4. **对比范围两派**：self-only（Original 行作锚，展示自身退化幅度有限）vs 跨模型（Clean 列作锚，展示"退化速率慢于基线"）。跨模型表的说服力更强，且必须共享同一套噪声/mask（MSF-GODE 明示公平性条款）。
5. **呈现**：表（Original/Clean 锚定行/列 + MSE/MAE）或折线/柱状图（x=污染强度，y=指标；或 mean±std 误差棒 + 显著性星号）。分析话术固定为"退化轻微/受限/不崩溃"，并把鲁棒性归因到具体结构（频域滤波、归一化、线性锚等）。
6. **统计**：多数论文无显著性检验；最严谨的是 MSF-GODE（10 次重复 mean±std + 配对 t 检验星号）。

### 2.3 期刊规范佐证

`assets/neurocom-spec.md` §3.5：Robustness 出现在 **30/40** 篇 Neurocomputing 论文中，典型形式即"噪声注入（TF4TF σ=0.1/0.2/0.3；Waveformer 4.10）；异常注入"。

---

## 3. DD-Mamba 现状与缺口

- `5_Experiments.tex` 现有小节：Experimental details → Main Results → Component analysis → Hyperparameter sensitivity → Case study → Matched training efficiency。**无 robustness 小节，无相关表/图**；`tables/` 六个表文件亦无。
- 论文已有的可复用资产：
  - **matched five-seed rerun**（seeds 2024–2028，6 数据集 × 7 个 in-pipeline baselines，统一 split/评估代码）→ 这些 checkpoint 可直接用于 test-time 污染评估；
  - **六种子核心消融**（seeds 2024–2029，ETTh2/Weather/Solar）→ 自稳健分析可对齐同一套协议；
  - 论文的严谨性口径（验证集选配置、测试集不参与任何配置决策、mean±std、配对 t + BH 校正、descriptive vs confirmatory 区分）→ robustness 实验必须沿用同一口径。
- 模型侧的鲁棒性叙事资源（写分析段用）：
  - **RevIN**：消融显示 normalization 是最大分量效应（ETTh2 上逆转 RevIN 惩罚随 H 增长）→ 直接对应"窗口级 level/scale 扰动免疫"；
  - **anchor-and-correction 残差结构**：DLinear 分解锚 + 零初始化 TD/FD 修正头 → Q-WaveMixer 式"graceful degradation（退化时凸门控回落到线性锚）"叙事天然成立；
  - **FITS 频域路径**：谱域低通特性 → 高斯噪声抑制的经典解释（Waveformer/FEDformer 同款话术）；
  - **注意反面**：Case study 已承认模型对突变有 smoothing bias——robustness 分析措辞需与之一致（不要声称对尖峰完全鲁棒）。

---

## 4. 推荐方案：Test-time corruption 协议（核心实验）

### 4.1 协议总则

- **已训练模型不动**：加载现有 checkpoint（DD-Mamba 与 in-pipeline baselines 的 matched-seed checkpoint），仅修改测试集数据管线。
- **只污染输入窗口 $X \in \mathbb{R}^{L \times C}$（$L=96$），永不污染预测目标 $Y$**。
- **在标准化空间施加污染**（数据已按训练分割标准化，均 0 方差 1）：高斯 σ 直接定义在标准化输入上；缺失以 0 填充（标准化空间中 0 即均值），语义清晰且与 RevIN 兼容。
- **公平性（MSF-GODE 条款）**：同一 (dataset, level, seed) 下所有模型使用完全相同的噪声张量 / 掩码——用独立于模型种子的确定性 generator（如 `torch.Generator().manual_seed(hash((dataset, corruption_seed, level, split_index)))`）预生成或在线重放。
- **评估口径**：沿用现有评估代码与 MSE/MAE 定义；每个 cell 报告跨 seeds 的 mean±std（与 matched rerun 的 5 seeds 对齐；若某 baseline checkpoint 不足 5 seeds，如实报实际数量并在 Notes 说明）。

### 4.2 污染族 1：加性高斯噪声（必做）

- 公式：$\tilde X = X + \epsilon,\ \epsilon_{l,c} \sim \mathcal{N}(0, \sigma^2)$（标准化空间，i.i.d.）。
- 水平：$\sigma \in \{0.1, 0.2, 0.3\}$（TF4TF 约定，语料最常见）。
- 换算说明（写入 Notes，二选一并固定）：标准化信号近似单位方差时，$\sigma=10^{-\mathrm{SNR}/20}$，故 σ∈{0.1, 0.2, 0.3} ≈ SNR ∈ {20, 14, 10.5} dB。**推荐直接用 σ 报告**（复现最简单），Notes 中给出 SNR 等价解释；不要两套参数化混用。
- 备选（不推荐做双份）：严格 SNR 定标（EIAformer 式，逐窗逐通道按信号功率定噪声）——如审稿人要求再补。

### 4.3 污染族 2：随机缺失 / 点掩码（必做）

- 公式：$\tilde X = X \odot M$，$M_{l,c} \sim \mathrm{Bernoulli}(1-r)$ 独立采样，缺失处置 0（标准化均值）。
- 水平：$r \in \{10\%, 20\%, 30\%\}$（ST-DAGCN 用 2–10%，MSF-GODE 块状缺失 30%；LTSF 输入为多通道窗口，10–30% 覆盖轻度到重度）。
- 可选加强（仅当时间允许）：块状缺失（连续 $k$ 个时间步整段掩掉，模拟传感器断连，MSF-GODE 场景）——作为图或补充说明，不进主表。

### 4.4 可选扩展（按优先级递减，均不阻塞主表）

1. **退化曲线图**（ST-DAGCN Fig.9 / Q-WaveMixer Fig.4 式）：x = σ（或 r），y = MSE，每模型一条线 + Clean 虚线锚；DD-Mamba 用主题色，baselines 用灰阶/muted palette。放在跨模型表旁边，视觉冲击力强。
2. **训练时污染重训**（TF4TF §4.7.1 式）：σ∈{0.1,0.2,0.3} 加到训练输入后重训，只做 DD-Mamba 自身 + ETTh2/Weather，报告 Original 行对照。成本 = 2 数据集 × 4 H × 3 σ 的重训，仅在主表结果偏弱时作为"训练侧也稳"的证据补充。
3. **异常注入**（TF4TF §4.7.2 式）：3% 时间点 × [-2x, 2x] 尺度扰动，ε∈{30%,50%,80%} 训练样本。优先级最低；神经计算语料中仅此一篇采用。

### 4.5 数据集 / 模型 / 种子选择

| 维度 | 推荐 | 理由 |
|---|---|---|
| 数据集 | **ETTh2 + Weather**（主表）；Electricity 视预算选做 | ETTh2 是消融锚（RevIN 效应最大、无 VC mixer）；Weather 开启 VC mixer ×2 + FITS 频域路径——两套配置覆盖论文全部机制家族；均为 matched rerun 覆盖的数据集。PEMS/Traffic/Exchange/Solar 的对比单元格来自发表数值、无本地 checkpoint，不纳入 |
| 预测长度 | $H \in \{96, 192, 336, 720\}$ | 与 TF4TF 表格式及本文主表一致 |
| 模型 | **DD-Mamba + S-Mamba, iTransformer, PatchTST, DLinear**（最小集）；TimesNet/FEDformer/Autoformer 等 7 个 in-pipeline baselines 中有 checkpoint 的均可加 | 覆盖 SSM / 倒置注意力 / patch-CI / 线性锚四个家族；DLinear 是鲁棒性叙事的关键参照（线性模型通常最稳，若 DLinear 退化更小要如实报告并解释）；S-Mamba 是主打对比对象。**禁止把发表数值单元格（来自 iTransformer 附录）混入本表**——它们没有对应可加噪声的模型实例 |
| 种子 | 污染种子与模型种子解耦：模型 checkpoint 用现有 matched seeds（2024–2028）；每 (dataset, level) 的噪声/mask 用固定独立种子集（建议 3 个污染种子，报告跨模型种子 × 污染种子的 mean±std） | 与论文现有 5-seed 口径对齐；污染随机性可控可复现 |

### 4.6 统计与报告口径

- 每 cell：mean±std（模型种子 × 污染种子）。
- **相对退化率**（EIAformer "slower degradation" 的量化版，必须报）：
  $\Delta_\sigma = (\mathrm{MSE}_\sigma - \mathrm{MSE}_{\mathrm{clean}})/\mathrm{MSE}_{\mathrm{clean}} \times 100\%$（缺失族同理用 $r$）。
- 可选（与论文统计口径一致）：对每个污染水平，做 DD-Mamba vs 每个 baseline 的逐种子配对 t 检验（primary endpoint = 该水平下跨 H 平均 MSE），**明确标注为 descriptive**（非 predeclared confirmatory family，不做 BH 全家校正声明，除非决定纳入）。最低限度：在 Notes 声明 shared corruption seeds 与无重训。
- 合规红线：本实验为纯评估，不触碰配置选择；正文措辞沿用论文现有谨慎风格（"consistent with / suggests" 而非 "proves"）。

---

## 5. 结果呈现与 LaTeX 集成

### 5.1 放置位置与命名

- 新小节 `\subsection{Robustness analysis}\label{sec:robustness}`，插入 `5_Experiments.tex` 中 **Hyperparameter sensitivity 之后、Case study 之前**（语料中最常见的排布：sensitivity → robustness → 可视化/efficiency）。
- 新表文件 `tables/table_robustness.tex`；`5_Experiments.tex` 中的 `\input` 前保留多行注释块约定（与现有六个表一致）：

```latex
% ===========================================================================
% Table: robustness analysis under noise and missingness (label: tab:robustness)
% Body lives in tables/table_robustness.tex -- edit table content there.
% ===========================================================================
\input{tables/table_robustness.tex}
```

- 可选图 `figures/robustness.pdf`（退化曲线），`figure*` + `[tbp]`，宽度对齐 `sensitivity.pdf` 的 0.99\textwidth。

### 5.2 主表骨架（跨模型，EIAformer 式 Clean 锚定列 + TF4TF 式水平分组）

一张 `table*`，无竖线、无底纹，notes 置于 tabular 下方。行 = 模型，列 = Clean / σ=0.1 / 0.2 / 0.3（或 r=10/20/30%），两个 dataset × 4 horizons 的 MSE（MAE 可放第二张同构表或合并在 Notes 引出的补充材料）。骨架：

```latex
\begin{table*}[tbp]
\centering
\caption{Robustness analysis under input corruption at $L=96$.}
\label{tab:robustness}
\small
\setlength{\tabcolsep}{4.3pt}
\renewcommand{\arraystretch}{1.03}
\begin{tabular}{@{}llcccccc@{}}
\toprule
Dataset & Model & Clean & $\sigma{=}0.1$ & $\sigma{=}0.2$ & $\sigma{=}0.3$ & $r{=}10\%$ & $r{=}20\%$ & $r{=}30\%$ \\
\midrule
\multirow{5}{*}{ETTh2 ($H{=}96$)}
 & \textbf{\model{}} & \best{} & ... \\
 & S-Mamba & ... \\
 & iTransformer & ... \\
 & PatchTST & ... \\
 & DLinear & ... \\
\midrule
% ... Weather, H=96 panel; full grid or selected horizons per space budget
\bottomrule
\end{tabular}
\par\vspace{2pt}
\begin{minipage}{\textwidth}\footnotesize
\textit{Notes:} Corruptions are applied to standardized test inputs only; models are
not retrained, and prediction targets are never corrupted. All models share the same
noise tensors and masks per (dataset, level). $\sigma$ is the standard deviation of
additive i.i.d.\ Gaussian noise in the standardized space; $r$ is the point-missing
ratio with zero filling. Values are mean$\pm$std over matched model seeds and three
corruption seeds. Bold red and underlined purple mark the lowest and second-lowest
error per column.
\end{minipage}
\end{table*}
```

- 空间不够时的取舍（按序）：(1) MAE 移出主表；(2) horizons 收缩为 H=96+336 或只报 H=96（EIAformer 只用 H=96）；(3) 缺失族拆成第二张表 `table_robustness_missing.tex`。
- 若跨模型表空间紧张，**替代形态**：self-only 表（TF4TF 式，Original 行 + σ/r 行 × ETTh2/Weather × 4H，只报 \model{}）——更省列宽，但说服力降级，仅在 baseline checkpoint 不可得时退回此方案。

### 5.3 小节正文骨架（英文，沿用论文 读表→量化→归因→例外 模板）

段落结构（对齐现有 Component analysis / Hyperparameter sensitivity 的写法）：

1. **协议段**（贴 `\label{sec:robustness}` 后）：两类污染、σ 与 r 水平、标准化空间施加、不重训、共享扰动种子、指标含相对退化率。一句动机（呼应 ST-DAGCN 式"deployment faces imperfect data"）。
2. **读表+量化段**：Clean→最重污染的 Δ% 对比（"\model{} 的 MSE 相对退化 x%–y%，低于 S-Mamba 的 …% 与 PatchTST 的 …%"），缺失族同理；指出的例外要如实（若 DLinear 更稳，写明并解释线性映射对输入扰动的低敏感性）。
3. **Design attribution 段**（现有各小节都有，必须保留同款 `\textbf{Design attribution.}`）：RevIN 在两条预测路径前剥离窗口级 level/scale（解释 σ 与中等缺失下的稳定性）；DLinear 锚 + 零初始化修正头 + 凸门控 → graceful degradation（Q-WaveMixer 式措辞，但归于自身结构）；FITS 谱路径对宽带高斯噪声的低通滤波；同时承认与 case study 一致的局限（对突变/尖峰的 smoothing bias，不声称完全鲁棒），并声明该实验为机制归因提供的是与设计一致的证据而非因果证明。

### 5.4 编译与验证

- 新表/新节属于 text-only 编辑：`New-Item -ItemType Directory build`（若不存在）后 `pdflatex -output-directory=build main.tex`；扫描 `build/main.log` 的 `!` 行与 undefined 引用。若新增任何 `\cite`（如需引 ST-DAGCN/TF4TF 支持协议选择，可选），必须跑完整四连编译。
- 表格遵守 Neurocomputing 约定：无竖线、无单元格底纹、notes 在 tabular 下、`\model{}` 宏、`\best{}`/`\second{}` 标注（per-column 最低/次低）。
- 完成后 `codegraph sync`。

---

## 6. Coding agent 执行清单

按序执行，每步含验收标准：

1. **盘点 checkpoint 资产**：确认 matched five-seed rerun 的 DD-Mamba 与 baselines checkpoint 位置、覆盖 (dataset, H, seed)；产出一份数量清单。验收：ETTh2/Weather × {96,192,336,720} × 至少 {DD-Mamba, S-Mamba, iTransformer, PatchTST, DLinear} 可用。
2. **实现 corruption 模块**（`corruption.py` 或等价物）：
   - `gaussian(x, sigma, generator)` 与 `point_missing(x, r, generator)`；
   - 确定性种子派生：`seed = f(dataset, corruption_seed, level_kind, level_value)`；
   - 单元测试：仅污染输入不污染 target；同参数同种子比特级复现；mask 比例在容差内；缺失填充值 = 0。
3. **评估脚本**：`evaluate --corrupt {none,gaussian,missing} --level {0.1,0.2,0.3,0.1r,0.2r,0.3r} --corruption-seeds {3个}`，复用现有 test 管线与 MSE/MAE 计算；输出 JSON/CSV（每行：dataset, H, model, model_seed, corruption_seed, level, MSE, MAE）。验收：Clean 列与已发表 matched rerun 数值一致（回溯校验）。
4. **运行矩阵**：ETTh2+Weather × 4H × {clean, 3σ, 3r} × 模型集 × 模型种子 × 3 污染种子。纯推理，预计数小时内完成。
5. **聚合与表格生成**：算 mean±std 与 Δ%（相对 Clean，逐模型逐水平）；生成 `tables/table_robustness.tex`（套用 §5.2 骨架与 `\best/\second` 规则）与（可选）`figures/robustness.pdf`（退化曲线，muted palette，与 sensitivity.pdf 同风格）。
6. **LaTeX 集成**：`5_Experiments.tex` 插入小节 + 注释块 + `\input`；撰写协议段/读表段/Design attribution 段（英文，数值以实际结果填充）。
7. **验证**：quick compile → log 扫描；若动过 `\cite` 跑 full build；`codegraph sync`。
8. **记录**：机器可读产物（逐 seed CSV + 聚合表）归档，与论文现有 "machine-readable artifacts" 口径衔接。

### 预算参考

- 推理-only 主矩阵：~2 数据集 × 4H × 7 水平 × 6 模型 × 5 seeds × 3 污染种子 ≈ 5000 次评估前向，单卡小时级。
- 可选重训扩展（TF4TF 式）：2 × 4 × 3 × 1 模型的完整重训，天级——默认不做。

---

## 7. 合规红线（Do / Don't）

- **Do**：共享扰动种子（跨模型公平）；报告相对退化率；Notes 里写清 σ/r 定义、标准化空间、不重训、target 不污染；与 case study 的 smoothing-bias 结论保持一致措辞。
- **Don't**：把 iTransformer 附录的发表数值单元格放进 robustness 表（无法加噪声）；用测试集表现反向调整污染水平或挑选报告的 seed；在表中使用竖线/底纹；硬编码 "DD-Mamba"（一律 `\model{}`）；把 descriptive 结果表述为 confirmatory；混用 σ 与 SNR 两套参数化而不加说明。
