# Neurocomputing 写作规范：官方要求 × 语料范式

> 本规范由两方面证据综合而成，互相校验：
>
> 1. **官方要求**：`assets/neurocom-guide.md`（期刊 Guide for Authors 全文逐条核读）；
> 2. **语料范式**：`citation/NeuroCom/` 下 40 篇已发表 Neurocomputing 深度学习时间序列预测论文的**全文通读**（pdftotext 完整提取后逐篇阅读关键章节：结构、引言贡献、方法走查、实现细节、结果叙述、结论与文末声明）。
>
> 本文档为期刊写作风格与内容范例的客观记录，不针对任何特定稿件。

---

## 一、期刊定位与官方硬约束总表

### 1.1 期刊范围与文章类型

- Neurocomputing 发表神经计算领域的基础贡献：架构、学习方法、网络动力学分析、学习理论等；应用覆盖信号处理、语音、图像、控制、优化、金融预测等。
- **Regular article 必须与 Neural Networks / Learning Systems 直接相关**。官方明确**不接收**：纯动力系统、纯控制工程、纯模糊逻辑、纯图像处理、纯已有算法组合。
- 文章类型 7 种：Regular / Survey / Tutorial / Replication / Software publication / VSI / Editorial preface。
- **同行评审为单匿名**（single anonymized）——投稿时须包含完整作者信息（姓名、机构、通讯作者、邮箱）。

### 1.2 版式与前置要件（量化约束）

| 项目       | 官方要求                                                                                                                                                                                                |
| ---------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 源文件     | 可编辑格式；LaTeX 用`.tex`（**双栏排版仅允许 LaTeX**，Word 须单栏）                                                                                                                                     |
| 语言       | 美式或英式英语，**不可混用**                                                                                                                                                                            |
| 单位       | SI 国际单位制                                                                                                                                                                                           |
| 标题       | 简洁信息性，避免缩写与公式（公认者除外，如 DNA）                                                                                                                                                        |
| 标题页     | 作者全名 + 上标小写字母机构标注 + 机构全称（含国家）+ 通讯作者及邮箱                                                                                                                                    |
| 摘要       | **≤250 词**，独立成文；避免引用（必需时作者+年份）；避免非常规缩写（必需时首现定义）                                                                                                                    |
| 关键词     | **1–7 个**，英文，避免 "and"/"of" 式多词组合                                                                                                                                                            |
| Highlights | **鼓励**（非强制）；单独可编辑文件，文件名含 "highlights"；**3–5 条、每条 ≤85 字符（含空格）**                                                                                                          |
| 数学       | 公式为可编辑文本；变量斜体；e 的幂用`exp`；小分式用斜杠 X/Y；公式按出现顺序连续编号                                                                                                                     |
| 表格       | 可编辑文本；正文引用；顺序编号；caption 随表；**表注在表体下方**；**避免竖线与底纹**；"use tables sparingly"                                                                                            |
| 图         | 单独文件提交 + 正文引用；命名 Figure_1等；caption = 简短标题 + 描述；矢量 EPS/PDF；彩照 ≥300 dpi（单栏 ≥1063 px、全页 ≥2244 px）；线图 ≥1000 dpi；组合 ≥500 dpi；**避免多图合一**（无障碍）；色觉无障碍 |
| 附录       | 字母编号 A, B；内部公式/表/图独立编号（Eq. (A.1)、Table A.1、Fig. A.1）                                                                                                                                 |

### 1.3 文章结构要求

- 分节编号：`1.`、`1.1`、`1.1.1`；交叉引用用编号，不写 "the text"；摘要不编号。
- Acknowledgements 独立成节，置于 References 之前（不上标题页）。
- **CRediT 作者贡献声明必需**（14 角色中按实际填写，通讯作者负责声明）。
- **Research data Option C**：数据存入仓库并在文中引用链接；不可共享时须说明原因；Data statement 必需。
- **生成式 AI 使用声明**：若在稿件准备中使用了生成式 AI（不含语法/拼写检查类基础工具），首次投稿即须在 References 前新增声明节（官方模板见 §6.4）；未使用则不需。
- Vitae（作者简介 ≤100 词 + 证件照）为可选。

### 1.4 参考文献要求

- 正文引用：**方括号数字编号 `[3,6]`，按出现顺序编号**；可提作者名但必须给编号（"Barnaby and Jones [8] obtained..."）。
- 期刊名按 LTWA 缩写；提交时格式不强求（一致即可），录用后由排版套用期刊样式。
- 期刊样式示例：`[1] J. van der Geer, T. Handgraaf, R.A. Lupton, The art of writing a scientific article, J. Sci. Commun. 163 (2020) 51–59. https://doi.org/10.1016/j.sc.2020.00372.`
- 预印本须标注 "preprint" 或预印本服务器名 + DOI；**已有正式版的一律引正式版**。
- `[dataset]` / `[software]` 引用有专门模板；鼓励 DOI 链接。

### 1.5 声明与提交

- 竞争利益：用 declarations.elsevier.com 工具生成 Word 文档上传。
- 资助：标准句式列基金号；无资助用规定句 "This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit sectors."
- 提交前 checklist：通讯作者信息、全部文件（图/表/补充材料）、拼写检查、正文引用与文献表一一对应。

---

## 二、语料清单（40 篇，全文通读）

文件名 `NC_<author><year><short>.pdf`；条目见 `neurocom.bib`（key 与文件名一一对应）。2026-08 两轮采集：第一轮 12 篇（2025–2026 年通用架构），第二轮 28 篇（2023–2025 年，覆盖 Transformer/MLP/CNN/RNN/ESN/GNN/ODE/LLM/混合架构与通用 LTSF/时空/层次概率/不规则间隔等场景）。

| key                 | 年  | 主题                                    | 页  | 引用 |
| ------------------- | --- | --------------------------------------- | --- | ---- |
| zhang2025tf4tf      | 25  | 时频多语义 Transformer（PLW+GFF）       | 12  | 55   |
| viehweg2025esn      | 25  | ESN 储层拓扑系统研究                    | 15  | 73   |
| liu2025gctgnn       | 25  | 图聚类 GNN 图时序预测                   | 12  | 54   |
| dong2025meainet     | 25  | 多视角嵌入+注意力交互                   | 12  | 63   |
| liu2025amsformer    | 25  | 自适应多尺度+谱过滤 Transformer         | 14  | 42   |
| su2025kbls          | 25  | 核广度学习 Cauchy 共轭梯度              | 13  | 43   |
| li2025dualnet       | 25  | 双路径自适应补偿网络                    | 12  | 49   |
| chen2026dytimenet   | 26  | 动态跨变量稀疏依赖（DropFusion）        | 23  | 50   |
| duan2026mpgtimer    | 26  | 长上下文多尺度 patch 图增强 Transformer | 17  | 41   |
| jiang2026qwavemixer | 26  | 量子-经典混合小波网络                   | 14  | 47   |
| kui2026tfkan        | 26  | 时频双分支 KAN                          | 15  | 41   |
| chu2026adafmp       | 26  | 波动感知多尺度 patch 网络（F10.7）      | 11  | 29   |
| bai2023cacrn        | 23  | 聚类感知卷积循环网络 MTS                | 13  | 46   |
| zhang2023robustrnn  | 23  | 鲁棒 RNN（局部随机敏感度正则）          | 15  | 47   |
| liu2023nitsgru      | 23  | 非等间隔 GRU-ODE 预测                   | 13  | 46   |
| yang2024graformer   | 24  | 门控残差注意力 Transformer              | 9   | 57   |
| wang2024eins        | 24  | 兴奋-抑制神经突触循环单元               | 19  | 71   |
| ceni2024resesn      | 24  | 残差 ESN（理论密集：稳定性定理）        | 15  | 65   |
| liu2024stdagcn      | 24  | 时空双自适应图卷积交通预测              | 11  | 60   |
| yan2024cagnspde     | 24  | 图神经随机偏微分方程交通流              | 12  | 49   |
| fan2025acdn         | 25  | 分布特征提取网络（Auto/Cross 相关）     | 14  | 55   |
| jiang2025tcm        | 25  | 轻量 MLP + 仿射变换                     | 12  | 40   |
| lee2025hamn         | 25  | 层次感知记忆网络概率预测                | 12  | 39   |
| li2025stnet         | 25  | 季节-趋势双分支网络                     | 18  | 46   |
| li2025tsllm         | 25  | LLM 零样本负荷预测框架                  | 30  | 51   |
| liu2025dfcon        | 25  | 主频对比学习超长预测                    | 14  | 50   |
| liu2025msfgode      | 25  | 多尺度频域图 ODE 交通预测               | 19  | 37   |
| qi2025routeformer   | 25  | 路由机制 Transformer 交通流             | 15  | 61   |
| tian2025sdvsnet     | 25  | 空间膨胀卷积+变量自注意力               | 14  | 51   |
| wang2025eiaformer   | 25  | 混合分解+动态 patch+通道融合            | 16  | 69   |
| wang2025smamba      | 25  | S-Mamba：双向 Mamba 变量相关编码        | 14  | 77   |
| xie2025ginn         | 25  | 灰信息嵌入神经网络（小样本）            | 12  | 50   |
| xu2025mpmixer       | 25  | 多尺度 Patch Mixer 双端预测             | 13  | 39   |
| yeo2025deepdfvar    | 25  | 动态因子 VAR + 深度残差（HPI）          | 26  | 90   |
| zhang2025mwenet     | 25  | 多小波增强 LSTM 趋势-季节               | 17  | 49   |
| zhang2025sab        | 25  | 替代注意力/FFN 结构矩阵框架             | 29  | 82   |
| zhao2025admslstm    | 25  | DFT-自相关金字塔分解 LSTM               | 13  | 65   |
| zheng2025mpfgsn     | 25  | 多分辨率 patch 傅里叶图谱网络           | 14  | 48   |
| zheng2025pine       | 25  | 混合独立通道 MLP 编码器（负载）         | 11  | 55   |
| cao2025waveformer   | 25  | 时频域电力长期预测                      | 15  | 40   |

> 采集口径：从本地 127 个 PDF（两轮累计）中剔除重复 8、离题 30（综述×5、异常检测/漂移/插补/聚类/视觉/软件/UQ/特征选择等）、以及为控制语料规模而裁剪的领域应用包装类与冗余储备池家族 33 篇（能源/风/光/雾/旅游/发酵等应用集成、AutoML/特征选择、超出配额的 ESN 变体与交通 GNN 变体）——在"深度学习时间序列预测架构"主题内优先保留通用方法学论文，总量对齐 30–40 篇目标。

---

## 三、结构范式（逐节骨架）

### 3.0 总体骨架

主流结构（37/40）：**Introduction → Related work（或 Literature review/Preliminaries）→ (Problem statement/Preliminary) → Methodology/Model → Experiments → Conclusion**。页数 9–30（中位 14）；**无硬性页数上限**，篇幅由内容支撑度决定。

**节级变体**（保留论文实证）：

| 变体                                   | 实例                                                                                           |
| -------------------------------------- | ---------------------------------------------------------------------------------------------- |
| 独立**Theoretical analysis** 节        | GRAformer §5、SAB §5（表达力/复杂度/可训练性三小节）、ResESN §4（线性稳定性，Theorem 4.2/4.3） |
| 独立**Discussion** 节                  | EINS §6、DFCon §6、Ada-FMP §4、SAB §7 拆为 7.1 Conclusion / 7.2 Discussion / 7.3 Future works  |
| 独立**Limitations** 节                 | TSLLM §6 Limitations（编号节）；Ada-FMP §4.2；DualNet §4.6                                     |
| 独立**Future work** 节                 | S-Mamba §7 Future work（与 §6 Conclusion 分离）                                                |
| **Failure analysis** 节                | Routeformer §6（失败案例归因）                                                                 |
| **Challenges and future direction** 节 | MWENet §7                                                                                      |
| 实验小节以**研究问题**命名             | S-Mamba §5.6–5.9（"Can variate order affect the performance of S-Mamba?" 等）                  |

### 3.1 Introduction

**长度与段落**：226–1949 词（中位 ~950），5–8 段；引用密度高。

**漏斗形模板**（全员一致）：

```
段落 1: 领域背景 + 应用价值
段落 2: 方法演进（统计 → 深度 → Transformer/图/多尺度/SSM），逐类一句评述
段落 3: 挑战/缺口精确陈述（常配动机图 Fig. 1 或实证动机表）
段落 4: "To address this issue/challenge, this paper proposes X" + 组件走读
段落 5: 贡献列表（3–5 条）
段落 6: roadmap 段（16/40 ≈ 40%，**可选非强制**）
```

**动机证据**（约 3/4 论文在 Intro 放图或表）：数据可视化（相关矩阵随时间变化 DyTimeNet、趋势+聚类四联图 GCTGNN、小波 vs 傅里叶对比 Waveformer Fig.1、层次序列稀疏性直方图 HAMN Fig.1）；实证动机表（DyTimeNet Table 1：Transformer w/ vs w/o Attention）；方法对比表（MPGTimer、MWENet Table 1 Related-work summary）。

**贡献列表形态**（六种并存）：

| 形态                      | 实例                                                                         |
| ------------------------- | ---------------------------------------------------------------------------- |
| bullet（•，主流）         | TF4TF、MEAI-Net、AMSFormer、DualNet、DyTimeNet、S-Mamba、MWENet、DFCon、PINE |
| 编号 (1)(2)(3)            | GCTGNN、NITS-GRU、MPMixer                                                    |
| 数字编号 1. 2. 3. 4.      | EIAformer、MSF-GODE（5 条）、ADMS-LSTM（5 条）、MPFGSN（3 条）、TCM          |
| 字母编号 a. b.            | Robust-RNN                                                                   |
| First/Second/Third 散文式 | PINE（"First, we propose..."）                                               |
| 无标记散文段              | GINN（一段连续行文概述贡献）                                                 |

惯例：**末条为实验条**（带量化提升数字："average 3.13% improvement"、"up to 13.8% MSE reduction"、"12.4% average performance enhancement alongside 61.3% parameter reduction"）。Deep-DFVAR 的 bullet 贡献内嵌证据指针（"see Fig. 12"、"see Table 6"）。

**roadmap verbatim**（40% 论文）：

> "The remainder of this paper is organized as follows. Section 2 describes the related research work. ... Finally, Section 5 concludes the paper."（GCTGNN）

### 3.2 Related Work

**独立节 37/40**；节名 `Related work` / `Related works` / `Literature review`（EINS）/ `Preliminaries`（KBLS、GINN、SAB 含 2.x 背景小节）。

组织形态两种：编号子节式（S-Mamba 2.1 TSF → 2.1.1 Transformer-based / 2.1.2 Linear models → 2.2 Applications of Mamba；PINE 2.1–2.5 按方法族 + 2.5 Challenges）；加粗导语段落式（TF4TF、MEAI-Net："MLP-based models:"）。

内容惯例：每篇被引工作一句具体评述（S-Mamba Related work 内逐作者一句："Wang et al. [33] propose Time Series MLP to..."）；子节尾转折指向本文；**同刊互引**实证（AMSFormer 引 TF4TF；DyTimeNet 引 S-Mamba；TCM/FTMLP 被 2025 年新论文引用）。

### 3.3 Preliminary / Problem Statement

独立问题陈述子节常见（S-Mamba 3.1、DFCon 3.1、Routeformer 3.1、CAG-NSPDE 4.1 "Symbols and problem definition"、HAMN §3）；1–2 段 + 1–2 个声明式公式；**符号表可选**（MSF-GODE Table 2 "Symbol table"、SAB Table 2 "Notations and Descriptions"）。

### 3.4 Methodology

**开场惯例**：总览段 + 架构图指针（"The entire framework of TF4TF method is illustrated in Fig. 2(a)."；"The overall framework of S-Mamba..."）。节名 `Methodology` / `Method` / `Model` / 模型名（`3. STNet`、`3. MPGTimer`）。

**组件走查范式**（全员一致）：动机段 → 声明式公式（编号）→ "where ..." 逐符号解释 → 直觉 → （可选）设计理由对比段。

**公式密度**：TF4TF (1)–(24) 量级常见；canonical 组件（LSTM 单元方程）可整组复述（MWENet "recall the canonical LSTM equations as implemented in PyTorch"）。

**定理文化总体缺席，但有明确少数派**（约 5/40）：

| 形式化元素                 | 出现论文                                         | 性质                                                                                                                                                    |
| -------------------------- | ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Theorem                    | ResESN(11)、MPFGSN(9)、GINN(5)、SAB(4)、TF4TF(2) | ResESN/SAB/GRAformer 为**自证**稳定性/表达力定理（配独立 Theoretical analysis 节）；TF4TF/MPFGSN 为**引用**已知定理（Parseval/卷积定理/谱图理论）作动机 |
| Proposition                | KBLS(2, 反证法收敛证明)、SAB(3)                  | 算法理论型点缀                                                                                                                                          |
| Definition/Lemma/Corollary | 0/40（编号形式）                                 | —                                                                                                                                                       |

**复杂度分析**：37/40 有效率内容；方法节内（SAB §5.2 逐 LP/Attention/FFN 推导、MPFGSN 4.3.4、CAG-NSPDE）或实验节效率小节，常配复杂度对照表（TF4TF Table 9、Routeformer Table 6）。

**实现细节隔离**：40/40 一致——optimizer/batch/epoch/GPU 只出现在 Experiments。

### 3.5 Experiments

**子节骨架统计**（40 篇并集，按出现频率）：

| 模块                         | 频率                                        | 典型节名                                                                                                                          |
| ---------------------------- | ------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| Datasets                     | 40/40                                       | 统计表（Variates/Timesteps/Granularity）；划分协议声明                                                                            |
| Baselines                    | 40/40                                       | 按架构分组 + 逐条一句说明（S-Mamba bullet 式；CAG-NSPDE 编号 1.–12. 含代码仓库）                                                  |
| Implementation details       | 40/40                                       | 见 §4.2 verbatim                                                                                                                  |
| Main results                 | 40/40                                       | 读表→量化→归因→例外                                                                                                               |
| Ablation                     | 33/40                                       | w/o 变体；**存在性矩阵表**（MPMixer ✓/✗ 组件表）；变体编号讨论（MPFGSN 5.4.1–5.4.2 逐效应 1.–5.）                                 |
| Sensitivity / Hyperparameter | 36/40                                       | Parameter selection / Parameter study / Hyperparameter analysis                                                                   |
| Efficiency                   | 37/40                                       | 训练时间+显存+参数+复杂度表（S-Mamba Fig.5 MSE/Time/Memory 三联）                                                                 |
| Robustness                   | 30/40                                       | 噪声注入（TF4TF σ=0.1/0.2/0.3；Waveformer 4.10）；异常注入；Lookback 分析另计                                                     |
| **Lookback-length 分析**     | ~8/40                                       | MPMixer 4.4、SDVS-Net 4.7、MWENet 6.1、S-Mamba 5.8（"Can Mamba help benefit from increasing lookback length?"）                   |
| Visualization / Case study   | 38/40（可视化）/ 8/40（独立 Case study 节） | 预测曲线+置信区间；UMAP 特征投影（PINE Fig.3）                                                                                    |
| 统计显著性检验               | ~8/40                                       | Q-WaveMixer Friedman+Wilcoxon p 值表；STNet**Demšar Friedman + Nemenyi 后验 + 临界差分图**；MSF-GODE t-test；HAMN/Deep-DFVAR p 值 |
| 扩展实验                     | 若干                                        | EIAformer 4.4.3–4.4.5（COVID 数据集/高维/短期任务外推）                                                                           |

**数据集协议**：标准 LTSF 基准（ETT×4+Electricity+Weather+Traffic+Exchange+ILI+PEMS/Solar）遵循 Autoformer/PatchTST 协议并显式声明（"6:2:2 for ETT and 7:1:2 otherwise"；CAG-NSPDE "6:2:2, past hour → next hour"）；公平性声明（Deep-DFVAR："the same variables, data processing method, and experimental environment... followed the official implementations"）。

**主结果叙述模板**（读表 → 量化 → 归因 → 例外）：

> [读表] "Our model TF4TF achieves the state-of-the-art performance ... according to the results in Table 3."
> [量化] "achieved the best performance in 36 instances"；"among a total of 60 cases, AMSFormer achieved the best performance in 26 cases"；ADMS-LSTM 结论段逐数据集报 "(0.422→0.192)" 式对照。
> [归因] "We attribute this to MEAI-Net's ability to better capture temporal dependencies..."（试探语，见 §4.4）
> [例外] "Regarding Labour, our method did not outperform the other baselines. This result is likely due to the dataset's overall rightward trend..."（HAMN）

**Ablation 叙述模板**：

> "The term 'PLW+GFF' indicates the concurrent use of two modules ... Employing PLW and GFF individually resulted in an increase in MSE by 5.5% and 11.1%, respectively."（TF4TF）

变体命名：`w/o X`、组件缩写（GCTGNN-NC/-NA/-NF）、机制替换（FP-GLU vs Complete）、存在性矩阵符号（MPMixer ✓/✗）。

### 3.6 Discussion / Limitations / Conclusion

**显式 limitations 约 15/40**：独立节（TSLLM §6、Ada-FMP §4.2、DualNet §4.6、Routeformer §6 Failure analysis、MWENet §7）或结论段内诚实陈述：

> "Nevertheless, limited improvements in standard deviation control are observed, indicating persistent challenges in training stability. This limitation is primarily attributed to ..."（Ada-FMP）
> "Although the results on benchmarks showed moderate improvements, it offers valuable insight into the trade-off..."（GRAformer，罕见的自我克制表述）
> "Despite these advancements, SDVS-Net does have limitations. Its superior performance is most pronounced on datasets with substantial variable dependencies..."（SDVS-Net）

**Conclusion 形态**：词数 0（个别解析缺失）–1778（中位 ~300）；开头收敛于 "In this paper/work/study, we propose/present X"；内容三要素：方法总结 → 实验结论（关键数字）→ future work（一句式 / "First, ... Second, ..." 两点式 / 独立节）。节名 `Conclusion` / `Conclusions` / `Conclusion and future work(s)` / SAB 式三段拆分 7.1–7.3 均有。

---

## 四、语言风格

### 4.1 Abstract

**单段四段式**（背景+不足 → 方法 → 组件走查 → 实验验证）；实测 103–344 词（中位 ~198）；**34/40 ≤250**（超限 6 篇——官方上限投稿仍应遵守）。无引用编号、无公式；代码句可选（TFKAN 摘要末）。

### 4.2 Implementation Details verbatim（写进正文的标准模板）

> "All experiments were conducted using PyTorch on an NVIDIA Tesla V100 GPU and an NVIDIA GeForce RTX 3090. We used the Adam optimizer [63] for training, starting with a learning rate of 10−4 and a batch size of 32, with the learning rate halving after each epoch. ... The model was trained for a maximum of 100 epochs, with early stopping applied based on validation loss."（MEAI-Net）

> "For training, we use a batch size of 32 and a maximum of 15 epochs. Early stopping is applied if the validation loss does not improve for 3 consecutive epochs. We optimize the models using the Adam optimizer with a learning rate of 1e−4 ... To ensure statistical significance, we conduct 10 independent trials for each model-dataset combination and report the averaged results."（AMSFormer）

> "The MPFGSN model is implemented in Python using PyTorch 2.2.0 and is trained on a GPU (NVIDIA GeForce RTX 4090), and source codes are available on github. We set the input window size T to 96 or 192 and the learning rate to 0.0001. The RMSprop optimizer is used..."（MPFGSN——非 Adam 优化器亦有先例）

> "The training process is divided into three stages: firstly, pre-training EIAformer for 20 epochs; secondly, fine-tuning EIAformer's prediction head for 10 epochs; and finally, fine-tuning EIAformer's whole network for 100 epochs."（EIAformer——多阶段训练描述）

配套内容：输入/预测长度声明（"T ∈ {96,192,336,720}, following the settings proposed in Autoformer"）、逐数据集超参表（GRAformer Table 4、MWENet Table 4）、硬件与框架版本、划分协议、公平性声明、多种子重复（"All experiments were repeated five times, and their average values were recorded"，ACDN）。**代码开源声明 21/40**（GitHub 链接于摘要末/实验设置/基线列表/结论）。

### 4.3 人称与自称

| 特征                 | 语料实测                                                     |
| -------------------- | ------------------------------------------------------------ |
| **"In this paper"**  | 38/40 使用（1–12 次），**绝对主流**                          |
| "In this article"    | 2/40（个别行文偶然出现，非自称惯例）                         |
| "In this study/work" | 变体补充（MEAI-Net、SDVS-Net、STNet、MWENet、Deep-DFVAR 等） |
| "the proposed X"     | 多数论文使用，与 "our model" 交替                            |
| 通讯人称             | "We" 第一人称为主；被动语态用于配置描述                      |

### 4.4 归因与试探语

归因句式（结果分析标配）："We attribute this to ..."、"This may/might be (attributed to) ..."（DualNet "the model might have overfitted to the periodic patterns"）、"indicating that ..."、"we can reasonably infer that ..."、例外交代（HAMN "This result is likely due to the dataset's overall rightward trend"；Q-WaveMixer "the p-value is 0.169, indicating that ... performs comparably"）。避免绝对化：不用 "prove"（数学证明语境除外）；全胜时才用 "state-of-the-art"。

### 4.5 图表 Caption 与表格标注

**Figure caption**：**40/40 为 "Fig. N. + 句子式描述"**（句点结尾，无冒号式，无 "Figure" 全拼起头）；子图 (a)(b)(c)(d) 标注惯例。

**Table caption**：**"Table N"（数字后无句点）**+ 标题/句子式；结果表必带标注说明句。标注方案实证：

| 方案                             | verbatim                                                                                                                                    | 使用                                                                                                                         |
| -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| bold + underline（主流）         | "The best results are highlighted in bold and the second-best results are underscored with underline."（TF4TF）                             | TF4TF、MEAI-Net、DyTimeNet、Q-WaveMixer、TFKAN、MPGTimer、Ada-FMP、ACDN、MSF-GODE、Deep-DFVAR、MPFGSN、CAG-NSPDE、PINE、HAMN |
| **bold red + underlined purple** | "The best results are highlighted in bold red font, while the second best results are presented in underlined purple font."（S-Mamba）      | S-Mamba                                                                                                                      |
| red + underline                  | "the best results are highlighted in red, and the second-best results are underlined"（AMSFormer）                                          | AMSFormer                                                                                                                    |
| red + blue                       | "The optimal and suboptimal results are highlighted in red and blue, respectively."（GCTGNN）；"blue indicates the second best"（SDVS-Net） | GCTGNN、SDVS-Net、MPMixer                                                                                                    |
| bold only                        | "the best performance is displayed in boldface."（CACRN）                                                                                   | CACRN、MWENet                                                                                                                |
| underline best + blue top-two    | "the best overall is underlined, while the top two results are highlighted in blue."（ResESN）                                              | ResESN                                                                                                                       |
| 图内标注                         | "The best results are marked with red circles."（MPFGSN Fig.5）                                                                             | MPFGSN                                                                                                                       |

表内数值 3 位小数为 LTSF 惯例；AVG 行与改进量 IMP% 列常见。

---

## 五、图表与篇幅定量参考

| 统计量           | 实测范围（中位）                                                   |
| ---------------- | ------------------------------------------------------------------ |
| 页数             | 9–30（~14）                                                        |
| 图数量           | 3–19（~9）                                                         |
| 表数量           | 2–33（~6；>10 者为多任务/多数据集论文如 SAB 29pp/Deep-DFVAR 26pp） |
| 引用条数         | 29–90（~50）                                                       |
| Intro 词数       | ~230–1950（~950）                                                  |
| Abstract 词数    | 103–344（~198）                                                    |
| Conclusion 词数  | ~300–1100（~300）                                                  |
| 关键词数         | 3–6                                                                |
| arXiv 预印本引用 | 0–41 条（中位 ~5、均值 ~7）——普遍存在但占比通常 <20%               |

图表类型谱系：架构图（全员）、动机可视化（~3/4）、预测拟合曲线（含置信区间）、注意力/权重热图、误差分布箱线图、雷达图、MACs-Params 散点、复杂度对照表、参数量/显存逐 horizon 表、Friedman 排名 + Wilcoxon p 值表、临界差分图（STNet）、UMAP 特征投影（PINE）、消融存在性矩阵（MPMixer）。

---

## 六、文末声明区块与提交要件

### 6.1 固定区块顺序（References 之前，40/40 实测）

```
Conclusion
→ CRediT authorship contribution statement   (40/40)
→ Declaration of competing interest          (40/40，模板句逐字)
→ Acknowledgements / Funding                 (32/40，含基金号；无资助用规定句)
→ Declaration of generative AI ...           (1/40，仅实际使用者)
→ Data availability                          (39/40)
→ References                                 (数字顺序制)
→ (可选) 作者简介 Vitae + 照片               (约半数)
```

**CRediT verbatim**（TF4TF）：

> "Xueer Zhang: Writing – review & editing, Writing – original draft, Visualization, Validation, Supervision, Software, Resources, Project administration, Methodology, Investigation, Funding acquisition, Formal analysis, Data curation, Conceptualization."

**Competing interest 模板句**（逐字）：

> "The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper."

**Data availability 变体**："Data will be made available on request."（TF4TF、AMSFormer）/ "I have share the link to my data in the paper."（DyTimeNet）/ 首页 "Dataset link:" 注记（MPGTimer）。

**AI 声明 verbatim**（MPGTimer，40 篇中唯一）：

> "During the preparation of this manuscript, the author(s) used a generative artificial intelligence tool ChatGPT (OpenAI, GPT-5.2) for language editing and grammatical checking. All content was reviewed and approved by the author(s), who take full responsibility for the final manuscript."

### 6.2 附录

- ESN Appendix A（逐数据集微分方程定义，Eq. (A.1)–(A.10) 独立编号 ✓ 符合官方格式）；
- MPGTimer Appendix A/B（超参数表 + 附加消融）；SAB Appendix A/B（理论扩展 + 数据集细节）；Deep-DFVAR 附录超参表（Table 7）。

### 6.3 引用实践

- 数量 29–90 条（中位 ~50）；**无官方数量区间**。
- 来源构成：NeurIPS/ICLR/ICML/AAAI/KDD 等顶级会议 + Elsevier 期刊（Neurocomputing 同刊互引常见）+ 少量专著；ICLR 条目可带 openreview.net URL。
- **arXiv 预印本引用普遍存在**（0–41 条/篇，中位 ~5、均值 ~7，标注 "arXiv preprint arXiv:xxxx"）——官方"有正式版引正式版"的要求在语料中执行不严格，投稿时仍应优先正式版。

---

## 七、写作核对清单（投稿前自查）

1. 版式：elsarticle 双栏 LaTeX（`[final,5p,times,twocolumn]`）；美式或英式英语统一；
2. 标题页：全作者 + 上标机构 + 通讯作者邮箱（单匿名评审须含作者信息）；
3. 摘要 ≤250 词、独立成文、无引用无公式；关键词 1–7 个；
4. Highlights：3–5 条 × ≤85 字符，单独文件，文件名含 "highlights"；
5. 结构：编号分节（1.1 / 1.1.1）；Intro 漏斗形 + 贡献列表（3–5 条，末条实验条）+ roadmap（可选，~40%）；Related work 独立节（37/40）；
6. 方法：组件走查 + 公式 + "where ..." 解释；无实现细节；复杂度分析；定理文化非必需（自证定理仅见于理论密集型少数派）；
7. 实验：Datasets（统计表+划分协议）/ Baselines（按架构分组）/ Implementation details（框架、GPU、优化器、batch、lr、epochs、early stopping、多种子）/ Main results（读表-量化-归因-例外）/ Ablation（w/o 变体或存在性矩阵）/ 效率（时间+显存+参数+复杂度）/ 敏感性 / 鲁棒性 / Lookback 分析（可选）/ 预测可视化；统计检验可选（Friedman+Wilcoxon/Nemenyi 为范例形态）；
8. 图表：Fig. N. 句点式 caption；Table N 无句点；结果表带 best/second 标注说明句（方案见表 §4.5）；表无竖线无底纹；图正文引用；
9. 文末区块：CRediT（14 角色）→ competing interest（模板句）→ 资助 → （如适用）AI 声明 → Data availability（Option C）→ References（数字顺序制，LTWA 缩写，预印本标注）；
10. 附录（如有）：A/B 编号 + Eq. (A.1)/Table A.1/Fig. A.1 独立编号；
11. 数字可溯源：所有实验数字来自代码/表格源，不凭空制造。

---

## 八、参考文献来源与年份分布（40 篇语料，共 2124 条）

> 提取口径：对 40 篇 PDF 做双栏裁剪文本提取，截取 References 标题至作者简介（Vitae）之间的全部条目，逐条按关键词表分类来源、按 `(年份)` 优先规则提取年份；无法判读年份约 24 条（1.1%）。个别条目因跨栏/乱码误差 ±1–2 条，占比数字保留一位小数。

### 8.1 总体构成（按文献类型分组）

| 分组            | 条数 | 占比  |
| --------------- | ---- | ----- |
| 期刊论文        | 1131 | 53.2% |
| 会议论文        | 668  | 31.5% |
| arXiv 预印本    | 263  | 12.4% |
| 专著/教材       | 44   | 2.1%  |
| 数据集/网站条目 | 9    | 0.4%  |
| 软件条目        | 7    | 0.3%  |
| 技术报告        | 2    | 0.1%  |

期刊与会议合计 84.7%，是引用主体；arXiv 预印本每篇中位 ~5、均值 ~7 条（见 §8.5）。

### 8.2 期刊来源细分

| 来源              | 条数 | 占全部引用 | 说明                                                                                                                                               |
| ----------------- | ---- | ---------- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| Elsevier          | 396  | 18.6%      | 第一大出版方；其中**Neurocomputing 同刊自引 82 条（3.9%）**，25/40 篇至少引用 1 条同刊论文（每篇 0–11，中位 1）                                    |
| IEEE              | 223  | 10.5%      | IEEE Trans. 系列为主（Neural Netw. Learn. Syst. / Knowl. Data Eng. / Cybern. / Intell. Transp. Syst. 等）+ IEEE Access                             |
| Springer          | 86   | 4.0%       | Neural Comput. Appl.、Appl. Intell.、LNCS、Artif. Intell. Rev. 等                                                                                  |
| Nature/Science 系 | 54   | 2.6%       | Nat. Mach. Intell.（时序预测高被引）、Nature、Sci. Rep.、Science                                                                                   |
| MDPI              | 33   | 1.6%       | Sensors、Energies、Appl. Sci.、Mathematics 等                                                                                                      |
| MIT Press         | 17   | 0.8%       | Neural Computation 等                                                                                                                              |
| 其他期刊长尾      | 295  | 13.9%      | 金融/经济（J. Finance、Econometrica、Econ. Model.…）、物理/混沌（Chaos、Phys. Rev.、Scholarpedia…）、能源/交通/医学等领域期刊；单一来源多为 1–3 条 |

### 8.3 会议来源细分

| 会议           | 条数 | 占全部引用 |
| -------------- | ---- | ---------- |
| NeurIPS        | 188  | 8.9%       |
| ICLR           | 127  | 6.0%       |
| AAAI           | 103  | 4.8%       |
| ICML           | 67   | 3.2%       |
| KDD            | 41   | 1.9%       |
| CVPR/ICCV/ECCV | 31   | 1.5%       |
| IJCAI          | 22   | 1.0%       |
| 其他会议       | 89   | 4.2%       |

- 四大顶会 **NeurIPS + ICLR + ICML + AAAI 合计 485 条（22.8%）**，是除期刊之外最大的单一来源簇。
- 数据挖掘/信息检索族（KDD+CIKM+WSDM/SIGIR+SIGMOD+WWW+VLDB+ICDM）合计约 71 条（3.3%）。
- "其他会议"含 IJCNN、ICASSP、ACL、MLSys、领域会议（能源/交通/气象等）与少量无法细分者。

### 8.4 引用年份分布

| 年份段    | 条数 | 占比  |
| --------- | ---- | ----- |
| ≤2014     | 379  | 17.8% |
| 2015–2019 | 433  | 20.4% |
| 2020      | 171  | 8.1%  |
| 2021      | 238  | 11.2% |
| 2022      | 251  | 11.8% |
| 2023      | 299  | 14.1% |
| 2024      | 249  | 11.7% |
| 2025–2026 | 80   | 3.8%  |

- **2020 年及以后的文献合计 60.6%**，近五年文献构成引用主体。
- 分组×年份：会议引用集中于 2015–2019（占会议 24%）与 2021–2024；期刊引用最平稳、≤2014 老文献占比最高（25%）；arXiv 集中于 2019–2024（占 arXiv 约 65%）。
- ≤2014 的老文献主要为统计经典（Box–Jenkins、Granger、STL/Cleveland、Holt–Winters）、混沌系统（Lorenz、Mackey–Glass）、信号处理与教材专著。

### 8.5 逐篇引用画像（条数 / 中位引用年 / 类型占比 / 前三大来源）

| 论文                | 条数 | 中位年 | 期刊% | 会议% | arXiv% | 前三大来源                         |
| ------------------- | ---- | ------ | ----- | ----- | ------ | ---------------------------------- |
| bai2023cacrn        | 46   | 2020   | 50    | 46    | 4      | Elsevier:11, IEEE:5, AAAI:5        |
| cao2025waveformer   | 40   | 2022   | 82    | 8     | 8      | Other:13, Elsevier:10, IEEE:5      |
| ceni2024resesn      | 65   | 2017   | 45    | 29    | 22     | arXiv:14, Other:9, Elsevier:9      |
| chen2026dytimenet   | 50   | 2023   | 20    | 56    | 22     | arXiv:11, NeurIPS:10, ICLR:8       |
| chu2026adafmp       | 29   | 2024   | 66    | 31    | 3      | IEEE:6, Elsevier:6, AAAI:4         |
| dong2025meainet     | 63   | 2019   | 48    | 43    | 10     | Elsevier:16, Other:9, NeurIPS:8    |
| duan2026mpgtimer    | 41   | 2023   | 27    | 54    | 10     | Elsevier:6, ICLR:6, NeurIPS:5      |
| fan2025acdn         | 55   | 2021   | 35    | 62    | 4      | NeurIPS:10, CV:8, Elsevier:7       |
| jiang2025tcm        | 40   | 2019   | 38    | 55    | 8      | Elsevier:7, NeurIPS:7, ICLR:4      |
| jiang2026qwavemixer | 47   | 2023   | 57    | 43    | 0      | ICLR:9, Other:8, Elsevier:8        |
| kui2026tfkan        | 41   | 2024   | 37    | 34    | 27     | arXiv:11, Elsevier:6, NeurIPS:5    |
| lee2025hamn         | 39   | 2019   | 38    | 38    | 18     | Elsevier:9, arXiv:7, ICML:5        |
| li2025dualnet       | 49   | 2023   | 53    | 27    | 20     | Elsevier:13, arXiv:10, Other:6     |
| li2025stnet         | 46   | 2019   | 48    | 19    | 29     | arXiv:14, Other:9, Elsevier:4      |
| li2025tsllm         | 51   | 2023   | 69    | 20    | 8      | Elsevier:17, Other:8, IEEE:5       |
| liu2023nitsgru      | 46   | 2017   | 78    | 15    | 2      | Elsevier:15, Other:13, Springer:3  |
| liu2024stdagcn      | 60   | 2020   | 85    | 8     | 7      | IEEE:20, Elsevier:15, Other:9      |
| liu2025amsformer    | 42   | 2022   | 43    | 38    | 19     | Elsevier:9, arXiv:8, NeurIPS:5     |
| liu2025dfcon        | 50   | 2022   | 38    | 54    | 4      | Elsevier:9, NeurIPS:7, AAAI:6      |
| liu2025gctgnn       | 54   | 2019   | 54    | 31    | 13     | Other:9, arXiv:7, NeurIPS:6        |
| liu2025msfgode      | 37   | 2023   | 54    | 41    | 0      | Elsevier:7, NeurIPS:4, KDD:4       |
| qi2025routeformer   | 61   | 2021   | 46    | 34    | 20     | Elsevier:14, arXiv:12, IEEE:8      |
| su2025kbls          | 43   | 2017   | 91    | 0     | 0      | IEEE:19, Other:9, Elsevier:6       |
| tian2025sdvsnet     | 51   | 2020   | 55    | 39    | 4      | Elsevier:13, IEEE:8, ICLR:6        |
| viehweg2025esn      | 73   | 2017   | 85    | 4     | 4      | Elsevier:20, Other:19, IEEE:11     |
| wang2024eins        | 71   | 2019   | 68    | 14    | 17     | Springer:21, arXiv:12, Elsevier:11 |
| wang2025eiaformer   | 69   | 2022   | 68    | 10    | 22     | Other:28, arXiv:15, IEEE:11        |
| wang2025smamba      | 77   | 2023   | 23    | 22    | **53** | arXiv:41, NeurIPS:8, Elsevier:6    |
| xie2025ginn         | 50   | 2022   | 94    | 2     | 0      | Elsevier:32, Other:6, IEEE:4       |
| xu2025mpmixer       | 39   | 2023   | 31    | 64    | 5      | ICLR:13, NeurIPS:7, Elsevier:6     |
| yan2024cagnspde     | 49   | 2021   | 27    | 63    | 10     | NeurIPS:12, IEEE:5, AAAI:5         |
| yang2024graformer   | 57   | 2020   | 65    | 28    | 7      | Other:23, Elsevier:7, arXiv:4      |
| yeo2025deepdfvar    | 90   | 2013   | 69    | 11    | 7      | Other:26, Elsevier:23, Book:11     |
| zhang2023robustrnn  | 47   | 2019   | 79    | 6     | 13     | IEEE:20, Elsevier:11, arXiv:6      |
| zhang2025mwenet     | 49   | 2023   | 61    | 33    | 4      | Other:10, IEEE:6, Springer:5       |
| zhang2025sab        | 82   | 2021   | 22    | 60    | 15     | NeurIPS:17, arXiv:12, ICLR:12      |
| zhang2025tf4tf      | 55   | 2022   | 22    | 56    | 22     | arXiv:12, NeurIPS:8, ICLR:6        |
| zhao2025admslstm    | 65   | 2020   | 74    | 17    | 8      | Elsevier:24, Other:10, IEEE:7      |
| zheng2025mpfgsn     | 48   | 2020   | 23    | 71    | 4      | ICLR:9, NeurIPS:7, Elsevier:6      |
| zheng2025pine       | 55   | 2021   | 56    | 18    | 15     | IEEE:18, arXiv:8, Other:5          |

**画像类型学**：

- **会议驱动型**（会议占比 ≥50%）：TF4TF、SAB、MPGTimer、DFCon、MPMixer、CAG-NSPDE、MPFGSN、DyTimeNet、ACDN、TCM——方法较新的通用架构论文。
- **期刊/领域驱动型**（期刊占比 ≥80%）：GINN(94%)、KBLS(91%)、ESN 拓扑(85%)、ST-DAGCN(85%)、Waveformer(82%)、RobustRNN(79%)、NITS-GRU(78%)——理论/领域应用倾向更强的论文。
- **arXiv 驱动型**：S-Mamba 的 arXiv 占比 53% 为全库最高（其方法族处于快速迭代期）；STNet 29%、TFKAN 27% 次之。
- 引用条数 29–90（中位 50、均值 53）；中位引用年 2013–2024（全库中位 ~2021）。
- "Other" 前三大来源出现于多篇论文，说明领域期刊长尾（金融/能源/交通/医学）是 NeuroCom 时间序列论文稳定的第三来源。

---

## 九、各章节篇幅分布（40 篇语料，词数实测）

> 口径：pymupdf 双栏裁剪提取全文，正文截至 References 标题（不含参考文献与声明区块）；按顶级编号标题切分章节；词数**含图/表 caption 与表格文字**；节标题缺失或命名非常规的论文不计入该节 n。因此数值高于 §五 中仅计正文行文的部分抽样口径，两表不可直接对比。

| 章节                    | 覆盖  | 中位数 | p25  | p75  | 最小 | 最大  | 占总词数中位占比 |
| ----------------------- | ----- | ------ | ---- | ---- | ---- | ----- | ---------------- |
| Introduction            | 40/40 | 1280   | 1081 | 1511 | 802  | 2543  | 12.2%            |
| Related work            | 32/40 | 1071   | 807  | 1252 | 353  | 1801  | 10.7%            |
| Preliminaries / Problem | 14/40 | 460    | 354  | 936  | 72   | 1376  | 4.1%             |
| Method                  | 40/40 | 1953   | 1422 | 2922 | 358  | 7206  | 19.0%            |
| Experiments             | 34/40 | 4106   | 2274 | 5016 | 279  | 14863 | 40.3%            |
| Conclusion              | 38/40 | 477    | 346  | 812  | 243  | 5258  | 4.7%             |
| Discussion（独立节）    | 5/40  | 1354   | —    | —    | 350  | 4265  | ~14%             |
| Future work（独立节）   | 2/40  | —      | —    | —    | 73   | 327   | —                |
| Theoretical analysis    | 2/40  | —      | —    | —    | 321  | 1423  | —                |

要点：

- **Experiments 是全文最大单节**（中位占 40%），Method 次之（19%）；Method+Experiments 合计中位 ~59%，其余前置章节合计约 1/4。
- Introduction 与 Related work 篇幅大体相当（约 1:0.85），Related work 可缺省（8/40 无独立节）。
- Preliminaries/Problem statement 出现于 35% 的论文，篇幅短（中位 ~460 词）。
- Conclusion 短小（中位 ~477 词，占 5%）；独立 Discussion/Future work 节是少数派（5 篇 / 2 篇），出现时可达全词数 14%。
- 正文总词数（不含参考文献）约 6500–23000（中位 ~9600），与页数 9–30（中位 ~14）对应。

---

## 十、其他重要信息（补充要点）

1. **引用条数与年份**：全库 2124 条、每篇 29–90 条（中位 50）；中位引用年 2013–2024（全库中位 ~2021）；2020 及以后文献占 60.6%——投稿时优先保证方法族近三年文献的覆盖。
2. **同刊互引是常态而非硬性要求**：25/40 篇至少引用 1 条 Neurocomputing（合计 82 条、占 3.9%；每篇 0–11、中位 1）；15/40 篇零同刊引用。引用 1–3 条同刊论文即可达标。
3. **四大顶会集中度**：NeurIPS/ICLR/ICML/AAAI 合计 22.8%，是方法创新的主要出处；Related work 与方法章节的方法族评述应优先覆盖这四家的近期工作。
4. **arXiv 引用惯例**：12.4% 的引用是预印本（每篇中位 ~5、均值 ~7 条），普遍标注 arXiv 编号；官方"有正式版引正式版"要求在实际语料中执行宽松，投稿时仍应优先正式版（与 §6.3 一致）。
5. **数据集与软件条目被正式编号引用**（Kaggle、UCI、GitHub、Zenodo 等出现在参考文献表而非脚注），LTSF 论文的数据声明与复现材料可循此惯例。
6. **领域期刊长尾**：金融/经济、物理/混沌、能源、交通、医学等应用期刊合计约 14%，说明 NeuroCom 论文普遍保留领域动机与经典统计文献；纯架构论文（如 TF4TF、SAB）可压缩此部分至 5% 以下。
7. **会议型 vs 期刊型论文的引用结构差异**：会议驱动型论文（§8.5）的 Related work 偏重四大顶会与 arXiv；期刊/领域驱动型论文保留更多 2014 年前经典文献（统计、混沌、教材）。
8. **本文稿件（DD-Mamba）对照**：当前 refs.bib 约 40 条，处于语料下四分位（29–50 区间内）；来源结构（Neurocomputing 同刊 ×3、NeurIPS/ICLR/AAAI、arXiv 若干）与语料范式一致；如需贴近中位，可在 Related work 补充 4–8 条近期四大顶会/同刊文献。

---

## 附：语料与统计方法说明

- 文本提取：`pdftotext -enc UTF-8`（TeX Live 2026）+ pymupdf 整册提取；页数经 `pdfinfo`；定量统计由 Python 正则脚本批量完成（脚本与中间产物位于本地临时目录，git-ignored）。
- 40 篇均经**人工通读关键区域**核验：章节骨架、贡献形态、caption 句式、back-matter 顺序、verbatim 引句直接取自全文；Intro/Abstract/Conclusion 词数为双栏提取下的近似值（个别论文脚本解析失败已剔除该字段）。
- 引用条数 = 参考文献 [n] 行首最大编号；表格标注方案逐表核对。
- `neurocom.bib` 条目经 DOI 内容协商（https://doi.org/<DOI></doi>，`Accept: application/x-bibtex`）获取；key 与文件名 `NC_<key>.pdf` 一一对应；Crossref 作者拼写缺陷已人工修正（DyTimeNet 的 "Wai Kin (Victor) Chan"）。
- **§八/§九 新增统计口径**（Python 3.12 + PyMuPDF 1.28 脚本，位于本地临时目录）：
  - 提取：逐页按列裁剪（左/右半版分别提取再拼接）以还原双栏阅读序；References 标题至 Vitae 之间为参考文献区，以 `[n]` 编号切分条目（STNet 等无括号编号论文走回退解析）。
  - 来源分类：约 150 条关键词/正则规则将条目归入期刊（按出版方）、会议（按具体会议）、arXiv、专著、软件、数据集等类别，首命中生效；无法归类的 13.9% 报告为"其他期刊长尾"。
  - 年份：优先取括号内 4 位年份，否则取条目末位年份；约 1.1% 条目（24/2124）无年份。
  - 章节篇幅：正文截至 References；顶级编号标题切分；词数含图表 caption 与表格文字。
  - 误差声明：跨栏/字号混排导致的条目切分误差约 ±1–2 条/篇；40 篇引用数与人工核对的 neurocom.bib 引用数一致性 39/40（adafmp 经复核为 29 条，已同步修正 §二 与 §五 表格）。
