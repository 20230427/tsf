# DD-Mamba 模拟审稿报告（Neurocomputing）

> **稿件**：*DD-Mamba: A Forecast-Decomposable Dual-Domain State-Space Framework for Multivariate Time-Series Forecasting*（elsarticle，5p/times/twocolumn，final）
> **审稿框架**：academic-paper-reviewer v1.10.0 · full 模式（EIC + 3 位同行审稿人 + Devil's Advocate，共 5 席独立评审 + 编辑合成）
> **校准**：标准 Neurocomputing 审稿人（单匿名评审、Regular article）
> **评审材料**：论文 LaTeX 全文（main.tex + 5 个节文件 + 6 张表 + highlights.tex）、 `assets/neurocom_specification.md`（40 篇 Neurocomputing 语料范式 + 官方 Guide for Authors 蒸馏）、`references/dd-mamba` 官方代码仓库（src/models、configs、results）、 已发表基线数值外部核对（S-Mamba、iTransformer）。
> **日期**：2026-08-30 · **总体决定**：**Major Revision（大修）**

---

## 评分与建议总表

| 审稿人     | 角色                     | 主要视角                     | 评分（/10） | 建议                              |
| ---------- | ------------------------ | ---------------------------- | ----------- | --------------------------------- |
| Reviewer A | Editor-in-Chief          | 期刊契合、原创性、整体质量   | 6.5         | Major Revision                    |
| Reviewer 1 | 方法学                   | 实验设计、统计效度、可复现性 | 5.0         | Major Revision                    |
| Reviewer 2 | 领域专家（SSM/时序预测） | 文献、理论、领域增量         | 6.5         | Major Revision                    |
| Reviewer 3 | 跨视角                   | 实用性、可复现性、资源成本   | 5.5         | Major Revision                    |
| Reviewer 4 | Devil's Advocate         | 核心论点挑战、逻辑漏洞       | —           | 无法支持 Accept（含 CRITICAL 项） |

> IRON RULE 执行：Devil's Advocate 在册 2 项 CRITICAL 问题，编辑决定不得为 Accept； 各报告相互独立撰写，重叠话题角度不同。

---

## 0. Phase 0：领域分析与审稿团配置

- **学科**：机器学习 / 深度学习 · 长期多变量时间序列预测（LTSF）
- **范式**： empirical/architectural——但以评估方法学（matched seeds、BH 校正、 exact-test 敏感性分析）为显著卖点
- **目标期刊档位**：Neurocomputing（CCF-C / JCR-Q2，神经计算基础贡献）
- **稿件成熟度**：主体实验完整、写作规范达标，但存在**结果溯源缺陷**与 **证据等级不一致**两类实质性问题，未达送审后直录水准

配置的 5 位审稿人身份：

1. **EIC**：Neurocomputing 领域编辑，专长神经架构与学习系统，重视期刊范围契合与 对读者群的实际价值；
2. **Reviewer 1（方法学）**：实验方法学与统计推断背景，长期关注基准测试偏差、 多重比较与可复现性危机；
3. **Reviewer 2（领域）**：SSM/Mamba 时序预测方向（S-Mamba、TimeMachine 一脉）， 熟悉 LTSF 标准实验电池与双域建模文献；
4. **Reviewer 3（跨视角）**：工业部署视角 + 软件工件评审经验，关注资源成本、 代码可复现性与实用价值；
5. **Devil's Advocate**：专职挑战核心论点、检测 cherry-picking 与确认偏误。

---

## 1. Reviewer A — Editor-in-Chief 意见

### 1.1 期刊契合度

论文属于神经架构 + 评估方法学工作，落在 Neurocomputing "neural networks / learning systems" 的核心范围内，与近年刊出的 S-Mamba（bidirectional Mamba 变量编码）、 TF4TF、TFKAN、Waveformer 等双域/SSM 时序预测论文构成直接对话。单从范围看， **没有契合度问题**。

### 1.2 原创性与显著性

本文的组件清单——DLinear 锚（Zeng et al.）、因果 Mamba 校正（Gu & Dao）、 FITS 式谱插值（Xu et al.）、RevIN（Kim et al.）、双向变量 mixer（S-Mamba）、 凸门融合——**每一项都是已有技术**。作者对此是诚实的（2_RelatedWork.tex:17 明确声明"not to claim the first decomposition, dual-domain network, or Mamba forecaster"），并将新颖性押注在两点：

1. **Forecast-level decomposability**：时域/频域各自输出完整预测，而非特征级融合， 使组件贡献可在预测层面分离；
2. **多重性控制的评估协议**：matched seeds + paired-t + BH 校正 + exact-test 敏感性分析。

这个定位本身是成立且有价值的——40 篇语料中几乎没有论文对自己的机制声明做 BH 校正，更罕见地报告"精确检验下无一致关效应存活"的阴性结果。**但按当前证据， 这两个卖点之间存在张力**（详见 Devil's Advocate）：架构增益在同等调参预算下 未被确立，而机制诊断的阳性结论又未通过作者自己设定的最严格证据门槛。 换言之，目前"经得起自己检验的结论（RevIN 有效）不是新的，新的结论（双域/ 机制收益）未经得起自己的检验"。

作为编辑我判断：该框架 + 这套评估协议仍有发表潜力，但需要一轮实质性返修， 把"什么被证实了、什么没有被证实"对齐到摘要、贡献列表与结论三处。

### 1.3 整体质量与表述

- 写作总体达到期刊水准：漏斗形引言、贡献四条、独立 Related Work、组件走查式 Methodology、标准实验电池（数据/基线/主结果/消融/鲁棒性/敏感性/案例/效率）、 完整的文末声明块——与 neurocom_specification.md §3 的语料范式高度一致。 §5.1 的跨论文数值来源说明（Numerical provenance 段）是同类论文中少见的规范做法。
- 摘要约 190 词（<250 ✓）、关键词恰 5 个 ✓、highlights 5 条且均 ≤85 字符 ✓、 CRediT/Funding/AI 声明/Data availability 块齐全 ✓。作者占位符 （main.tex:58-65）与致谢占位符（main.tex:97-98）投稿前必须落实—— Neurocomputing 为单匿名评审。

### 1.4 EIC 小结

**优点**：(1) 评估方法学远超本刊平均水平；(2) 局限性与威胁效度讨论罕见地坦诚； (3) 阴性结果保留（FITS 通道不提升均值、warmup-cosine 只降训练损失）。

**必须解决**：(1) 主表数值的配置溯源（Traffic/Electricity）；(2) 摘要、highlights、 贡献列表与正文证据等级对齐。**建议：Major Revision。**

---

## 2. Reviewer 1 — 方法学审稿报告

### 2.1 实验设计总体评价

论文的评估协议（matched seeds、种子级配对差、BH 家族校正、exact sign-flip 敏感性分析、效率研究全量种子均值）在 LTSF 文献中属于**最好的 5%**。多数投稿 连多种子都不做。但正因为论文把"multiplicity-controlled evaluation"列为贡献 (2)（1_Intro.tex:15），我有责任用同等严格的标准审查这套协议本身。 以下问题按严重度排列。

### 2.2 MAJOR 问题

**M1. 精确检验下最小可达 p 值使"4 项边际存活 BH"只能是参数检验结论。** 论文自述：5 对样本的 exact sign-flip 最小双侧 p = 0.0625，6 对为 0.03125， 3 对为 0.25（5_Experiments.tex:24）。这意味着：

- 统一基线比较（5 seeds，42 对照族）中任何对照在 α=0.05 的精确检验下 **数学上不可能**显著；摘要中"four of these margins remain significant after Benjamini–Hochberg correction"（main.tex:68）完全依赖 paired-t 的正态性 假设（df=4）。n=5 时 t 检验对差值的分布形状相当敏感。
- 核心消融（6 pairs）的最小 p=0.03125，单对照勉强可行，但论文自己的结论是 "No confirmatory core-ablation effect survives BH correction under the exact analysis"（5_Experiments.tex:24）。结论一节也自认"a larger-seed replication necessary"（7_Conclusion.tex:5），却未见相应计划。

**要求**：(a) 将种子数提升至 ≥10（此时 exact 检验最小 p≈0.002，才能支撑 "multiplicity-controlled"的贡献声明）；或 (b) 摘要、highlights、贡献 (4)、结论 四处统一降级表述为参数检验结论，并如实注明精确检验结论；(c) 报告效应量 （paired difference 的均值与 95% CI），而不仅是 p/q 值——目前全文没有任何 表格报告离差（见 M4）。

**M2. 基线调参预算不对等（作者自认，但后果被低估）。** 5_Experiments.tex:20 承认 7 个 in-pipeline 基线"architecture defaults were fixed without a comparable model-specific search"，且这些 rerun"do not establish equal tuning budgets or official-implementation fidelity"。这意味着推断性结论（"five of six datasets 最低平均 MSE"，5_Experiments.tex:54）建立在 **DD-Mamba 逐数据集调参 vs 基线固定默认配置**的不对称上。对照已发表数值可直接看到该不对称的影响：Electricity 上 \model{} 的 0.174（H=336）/0.169（avg）与 S-Mamba **已发表值** 0.176/0.170（table_horizons_general.tex:26-31）实质打平，增益主要出现在对 rerun 基线的比较中；而 PEMS04 效率面板中 rerun 的 S-Mamba（0.07704）又远好于其已发表值（0.103）， 说明 rerun 与已发表数值之间存在双向的系统差异，跨源排名无从校准。 代码仓库的 AGENTS.md 同样写明 "an expected value is not a result; run fresh before any accuracy claim"。**要求**：对 7 个基线执行与 \model{} 同 预算的逐数据集搜索（搜索空间代码库中已有：configs/baseline_search_spaces.yaml）， 或至少在正文显著位置量化该不对称的影响方向与幅度。

**M3. 主表（3 seeds）、统一推断（5 seeds）、核心消融（6 seeds, 2024–2029）、敏感性 （5 seeds, 2022–2026）、效率（5 seeds, 2024–2028）种子数与种子集不一致。** 主表是读者第一眼看到的证据，却是最弱的（3-seed 均值、无离差）。且 "five of six"的叙述来自统一 rerun（5_Experiments.tex:54），而主表展示的是跨论文 描述性比较——两条证据流在 Table 2/3/4 与 5.2 节文字之间并存，普通读者无法分辨 "\model{} 在 ETTm1 上多格最优（Table 2）"与"PatchTST better on ETTm1 （5_Experiments.tex:54）"为何同时成立。**要求**：主表统一升至与推断实验 相同的种子协议并标注 ±std。

**M4. 统计报告不完整：全文无任何表格报告离差或置信区间。** 主表（3 seeds）、 核心消融表（6 seeds，table_core_ablation_main.tex）、效率表（5 seeds， table_training_efficiency.tex）均只报均值。论文自己在 1_Intro.tex:9 指出 "Small ablation differences can be comparable to run-to-run variation"——那么每一个消融对比都应附 std 或 CI，否则读者无法判断 ETTh2 上 Mean fusion 0.288 vs full 0.293（H=96，Mean fusion 更好，table_core_ablation_main.tex） 这类反直觉格子是噪声还是效应。**要求**：所有多种子表格补 mean±std；对 "supported/not supported"的对照补效应量与 CI。

**M5. Solar 的 RevIN-off 决策证据与"test split 未参与配置"声明存在矛盾迹象。** 论文在**4 处**逐字重复声明："RevIN was disabled for Solar based on validation-set performance. The test split was not used for any configuration decision."（5_Experiments.tex:14、24；7_Conclusion.tex:18、23；另有表注 以引用 Section 5.1 的方式转述，table_horizons_general.tex:50、 table_core_ablation_main.tex:103）。同一句话防御性地重复，本身就需要解释。 更实质的问题：[代码核对] configs/solar.yaml:37-39 的注释写的是 `use_revin: false # ablation-verified: instance norm HURTS solar (-0.016 MSE @96)`——"ablation-verified"指向的是**测试集上的 消融指标**；而仓库中遗留的 results/Ablation_solar_final.json（3 seeds）显示 no_revin 平均 MSE 0.18022，与 full 的差异仅在 1e-4 量级（即**无差异**）， 与 "-0.016 @96" 的量级对不上。**要求**：(a) 提供该决策基于验证集的直接记录； (b) 说明 yaml 注释所指标定数据的来源；(c) 将重复声明合并为一处协议描述， 并解释为何 Solar 被排除在"predeclared confirmatory families"之外 （5_Experiments.tex:24）——目前时间线读起来像先看结果再定族。

**M6. Weather 配置的"margin-preserving"回退。** [代码核对] configs/weather.yaml:41-49 注释：mixer_placement 从 'shared' 回退为 'both'，理由是绑定损失 +0.0013 avg MSE 并"erases the Weather margin over PatchTST"。虽然论文将 Weather 定性为"tied"，但该注释表明配置选择过程中 **参考了其对相对排名的影响**。这与"validation-based configuration protocol" 的精神相悖（选择依据应是验证集绝对误差而非对特定基线的边际）。**要求**： 澄清该回退决策是否仅基于验证集 MSE；如是，请在正文 Weather 配置说明中写明 两种 placement 的验证集数值。

### 2.3 MINOR 问题

- **m1**：敏感性扫描仅在 ETTm1/Weather、H=96 上做，且 Weather 配置学习率 2e-4 不在网格内（5_Experiments.tex:30 已坦承并作未标记处理）。建议补上该点或删去 Weather 的 lr 面板解读。
- **m2**：42 对照 BH 族将 6 数据集 × 7 基线合并为单族——请讨论以数据集为 单位分族（6 个小族）时结论是否稳健（per-dataset BH 是更保守还是更宽松， 值得一句话说明）。
- **m3**：未报告推理延迟/吞吐（论文已在 threats 中自认，7_Conclusion.tex:18），鉴于部署叙事， 建议补测。

### 2.4 建议

**Major Revision**。评估协议的骨架是好的，问题集中在：种子数不足支撑精确检验 结论、基线预算不对等、全文无离差报告、以及两处（Solar、Weather）配置选择 过程的透明度。这些都是可修复的——修复后本文的实验部分将成为本刊的方法学标杆。

---

## 3. Reviewer 2 — 领域专家审稿报告

### 3.1 文献与定位

Related Work 覆盖充分且按"forecasting models / cross-variable & SSM / research gap"三段组织，引用了截至 2025–2026 年的双域工作（TF4TF、DecMamba、Waveformer、 TFKAN）与 SSM 系（Mamba、Mamba-2、S-Mamba、TimeMachine、FMamba），并与 TimeRecipe/CombinationTS 的模块级分析划清了边界（2_RelatedWork.tex:15）。 对我所在的小方向而言，定位是清楚的：**"within-model attribution under matched stochastic runs"**（2_RelatedWork.tex:15）。这个 niche 真实存在且未被占据。

**但有两处定位问题**：

**D1（MAJOR）：组件级基线缺失——FITS 与 DLinear/RLinear 的单独对照。** 频率分支的可选 backbone 就是 FITS（4_Method.tex:43-51），时间分支的锚就是 DLinear。那么读者自然会问：**单独的 FITS 和单独的 DLinear（含 RevIN，即 RLinear 变体）在这 9 个基准上表现如何？** Table 2/3 有 DLinear/RLinear 列 （引自 iTransformer 附录），但 FITS 完全缺席。FITS 原文在 ETTh2/Weather 上 是极强 baseline；若 \model{} 对 FITS 的增益主要来自 RevIN + mixer + 调参， 则"双域框架"的必要性论证会被削弱。**要求**：补 FITS（官方实现，L=96）作为 基线列，或在消融中报告 freq-branch-only（fusion=freq_only，代码已实现， fusion.py:31-32、141-143）在全部数据集上的表现——目前 w/o FD branch 只覆盖 3 个 数据集（ETTh2/Weather/Solar）。

**D2（MAJOR）：Methodology 深度低于本刊 SSM 论文的标准配置。** 对照 S-Mamba（§4.4 复杂度分析）、TimeMachine、本刊 40 篇语料中的理论节惯例 （neurocom_specification.md §3.0：独立 Theoretical analysis 节出现于 GRAformer/SAB/ResESN），本文 Method 全节仅约 3 页，缺少：

1. **复杂度分析**：时间/内存随 L、C、H、d 的渐近量（论文的效率劣势恰恰是 审稿焦点，更需要理论解释：双分支 O(C·L·d) 扫描 + 双向变量 mixer O(2·C·d²) 与 S-Mamba 单路 O(C·d²) 的对比）。论文正文目前只有定性一句 "Weight sharing limits parameter growth, but it does not remove the activations or computation of repeated branch and variate operations"（5_Experiments.tex:137）。
2. **mixer placement 维度未在 Method 中定义**：实验部分出现了"two separate two-layer VC mixers per branch"（Weather，5_Experiments.tex:28）、"two-layer shared VC mixer"（Traffic/Electricity，5_Experiments.tex:14；PEMS04，5_Experiments.tex:28）两种 placement（both/shared），但 4_Method.tex:55-56 只描述了"M-layer bidirectional Mamba mixer"。读者无法从方法节重建实验配置 空间。[代码核对] dual_domain_model.py:102-109 定义了 both/time/freq/shared 四种——请在 Method 中给出定义并说明选择依据。
3. **门控初始化 g₀≈0.9 的动机**：4_Method.tex:71 只陈述不解释。代码注释 （fusion.py:57，GATE_BIAS_INIT=2.2，sigmoid(2.2)≈0.90）给出了理由（初始时 频域头随机，均权混合会浪费高学习率阶段）——这个论证应该进正文，它是 "anchor-and-correction"设计哲学的一部分。
4. **Eq. (4) 中的代码切片记号 `[:,L:]`**（4_Method.tex:47）不应出现在数学公式 中；"implementation-aligned variable-major view" （4_Method.tex:44）是工程措辞，应改为纯数学表述（如 $\mathcal{P}_{[L:L+H]}(\cdot)$ 投影算子）。

### 3.2 机制诊断的兑现程度

论文标题级卖点是"mechanism-level diagnosis instead of a single aggregate score"（main.tex:68）。但作为读者，我在正文中看到的诊断输出只有 消融表 + $\overline{|r|}$ 相关统计（Eq. 5）两样。**框架最有说服力的诊断证据 反而缺失**：

- **学习到的门控值**：g 在各数据集上收敛到什么分布？如果 Weather 上 g→0.6 而 ETTh2 上 g→0.95，这是"频域贡献数据集依赖"的最直接可视化， 一张小图即可说服我。代码 return_components=True 已输出 time/freq 分支 预测（dual_domain_model.py:215、270），获取成本为零。
- **分支单独预测质量**：time_only / freq_only 模式（fusion.py:31-32、141-143） 在代码中存在，论文却只在 3 个数据集上给了 w/o 行。既然贡献 (1) 是 "independently removable"，就应在全部数据集给出 branch-alone 表现。
- **贡献 (3) 兑现不足**：1_Intro.tex:15 承诺"data-centric analysis using channel correlation, horizon, and dispersion as validation hypotheses"， 但 dispersion 统计在正文只出现一段文字（7_Conclusion.tex:13），无图表、 无数据支撑。要么补一个 correlation/dispersion × mixer 收益的散点分析， 要么删掉该贡献条目。

**要求（MAJOR）**：补门控分布图 + 全数据集 branch-only 表；裁剪或兑现贡献 (3)。

### 3.3 与基线对比的领域视角

- **Table 4（Traffic/PEMS）**：\model{} 在 Traffic（0.437 vs S-Mamba 0.414）、 PEMS04（0.116 vs 0.103）落后，PEMS03 落后 iTransformer（0.116 vs 0.113）。论文坦诚（5_Experiments.tex:54-56），且用"variate mixer 不是普适有利"解释。 但注意：**恰恰是 mixer 启用的高通道数据集上输给了以变量建模为核心卖点的 S-Mamba**。这削弱了"optional variate mixer"作为架构要点的说服力——它 在 ETT 类（0 mixer）上不存在、在 Traffic 类上又不如 S-Mamba 的专职 mixer。 建议在 Discussion 中正面处理这个不对称，而不是仅归因于调参预算。
- **变量顺序非置换不变**（4_Method.tex:56；7_Conclusion.tex:18 自认 无 stress test）：S-Mamba 原文专门有 §5.6 检验 variate order 影响。既然本文 的 mixer 沿用 S-Mamba 设计，至少应做一个 channel-permutation 对照实验 （成本极低：打乱列序重测一个数据集）。
- **缺 look-back 研究**：L=336/512 自 PatchTST/iTransformer 起是本领域标准 电池项（neurocom_specification.md 实验电池含 lookback study）。全文仅 L=96 （5_Experiments.tex:6）。鉴于线性锚 + FITS 类组件对 L 极其敏感（FITS 原文的主要收益来源 就是长 look-back），L=96-only 的设置实际上**避开了对双域设计最有利的 区域**，也避开了对线性锚最不利的区域。**要求（MAJOR）**：补 L∈{96,336,512} 至少两个数据集的 look-back 敏感性实验。

### 3.4 MINOR

- **m1**：Table 1 缺 PEMS03/04/07/08 行（正文 5_Experiments.tex:6 声称使用它们， table_datasets.tex 仅列 7 个长程数据集）。
- **m2**：关键词 "Multivariate analysis"（main.tex:72）在统计学科另有专门含义，建议改 "Multivariate time series"。
- **m3**：Fig.（case study）caption 称"the remaining colored lines are the four baselines"但未列出是哪四个；且 H∈{96,192,**384**}（5_Experiments.tex:116） 与全文 H∈{96,192,336,720} 不一致——384 是笔误还是独立实验？
- **m4**：Fig. 1 caption 内嵌生成式 AI 使用声明 （4_Method.tex:23）——期刊要求的声明节已存在于 main.tex:100-101， 图注中无需重复；保留亦可，但建议统一。
- **m5**：DecMamba/TF4TF 作为最近的 dual-domain 竞品只在 Related Work 一笔 带过（2_RelatedWork.tex:7），无任何数值对照或讨论其"feature-level fusion"与本文"forecast-level" 的实证差异。至少应补一段定性对比（两者在共同数据集上的已发表数字 vs 本文，标明跨论文性质）。

### 3.5 建议

**Major Revision**。方向有价值、写作规范，但方法节深度（复杂度、placement、 门控机制）与诊断承诺的兑现度（gate 可视化、branch-only、FITS 基线、look-back 研究）均低于本刊同类论文水准。

---

## 4. Reviewer 3 — 跨视角审稿报告（实用性 · 可复现性 · 资源成本）

### 4.1 资源成本与实用价值

效率研究本身设计得当（同硬件、同 batch、FP32、5 seeds、气泡图 + 表），且 论文如实报告了代价。但把数字放到部署视角下（table_training_efficiency.tex）：

| 面板          | \model{}                     | 最强竞对                            | 时间倍率 | 内存倍率 | MSE 相对改善（vs rerun） |
| ------------- | ---------------------------- | ----------------------------------- | -------- | -------- | ------------------------ |
| PEMS04 H=12   | 32.77 ms · 3.120 GB          | S-Mamba 9.74 ms · 0.355 GB          | 3.4×     | 8.8×     | −2.0%                    |
| Weather H=96  | 27.04 ms · 1.260 GB          | PatchTST 5.82 ms · 0.144 GB         | 4.6×     | 8.8×     | −0.9%                    |
| ETTm1 H=96    | 7.38 ms · 0.220 GB           | PatchTST 5.89 ms · 0.064 GB         | 1.3×     | 3.4×     | −0.5%                    |

若以面板内最低内存竞对计（如 Weather 的 iTransformer 0.028 GB），内存倍率 高达 45×。**核心关切**：效率面板的精度优势全部建立在对 *rerun* 基线的比较 上，幅度仅 0.5%–2%；而这些 rerun 与基线已发表值之间存在双向系统差异（见 Reviewer 1 M2），跨源比较无从校准。对 practitioner 读者，当前证据不足以论证 部署价值。我要求：

1. 增补 **inference latency / throughput** 测量（论文自认缺失， 7_Conclusion.tex:18）——对部署决策这比训练时间关键得多；
2. 补一个 **shared-mixer / placement 消融的资源维度**：代码中 mixer_placement = shared 可把 Weather 模型从 5.77M 降到 3.49M（weather.yaml:41-49 注释）， 代价仅 +0.0013 MSE。**这个帕累托点对实践者非常重要，论文却完全没有 展示**——正文只展示了 both-placement 的大模型配置。请补充该配置的 accuracy-cost 坐标，让读者自己选择；
3. 在效率节明确给出"每 1% MSE 改善的内存/时间成本"的量化表述。

### 4.2 可复现性（结合代码工件审查）

这是本报告的重点。论文多处自曝工件缺陷，我逐一核对：

**R1（CRITICAL）：Traffic 主表数值无法溯源到唯一工件，且论文与代码配置注释 互相矛盾。**

- 论文（5_Experiments.tex:14）：最终 Traffic 配方由 traffic.yaml 固定—— d=256、d_f=512、跨两分支共享的两层 VC mixer，约 2.92M 参数。
- [代码核对] configs/traffic.yaml:24-29 注释原文：*"NOTE: the manuscript's headline Traffic accuracy was measured at **d=512 with mixer_placement=both**; set both to reproduce Table 6"*——与论文陈述**正好相反**，且注释引用的 tab:hparams 标签在稿件中已不存在（现表标签为 tab:pems_traffic）。
- [工件核对] results/Main_traffic.json：`config.model` 字段为**空**（无配置 快照），3 seeds，horizon 均值 0.402/0.424/0.441/0.485（avg 0.438）； results/reduced_traffic_d256.json：5 seeds，0.401/0.423/0.444/0.480 （avg 0.437）。**Table 4 的 Traffic 行（0.401/0.423/0.441/0.481， avg 0.437，table_pems_traffic.tex:19-24）与两个工件均不完全一致**： H=96/192/720 匹配 reduced_d256，H=336（0.441）匹配 Main_traffic（0.4411）。这指向混合来源或第三条未存档的运行。
- 论文同时自认"Because several legacy aggregate results store only a configuration path rather than an immutable snapshot, fixing the final recipes does not retroactively establish provenance for every earlier numerical cell"（5_Experiments.tex:14）——遗留格子的溯源问题被**声明**而非被**解决**。代码仓库 AGENTS.md 自己的纪律是"pre-schema files are legacy_unverifiable and must not be merged into new resumable outputs"、audit 脚本 fail-closed——**主表数字正落在 legacy_unverifiable 区**。

**要求**：以 immutable config snapshot（仓库的 provenance schema 已支持： resolved config + SHA-256 + commit + seeds）重跑 Traffic 全部 4 个 horizon、 3+ seeds，用新工件替换 Table 4 行；解决论文↔yaml 注释矛盾（并清理 yaml 注释 对已不存在表格的引用）。Electricity 的遗留格子同理。

**R2（MAJOR）：正文自认"lacks immutable configuration snapshots and complete seed-level logs for several legacy results"（7_Conclusion.tex:18）。** 这不仅是卫生问题——结合 R1，它意味着主表与消融表中哪些数字有种子级记录、 哪些没有，读者无从判断。**要求**：随稿提交补充材料，列出每个表格单元格 → 工件文件 → seeds → config hash 的映射表；仓库中 results/ 已有 20+ JSON， 做一张索引表成本很低。

**R3（MAJOR）：论文未提供代码/工件可用性声明。** Data availability 仅一句 "Data will be made available on request"（main.tex:103-104）——本文全部 9+4 个基准都是公开数据集，这句话不成立；且论文声称的"machine-readable audit"（5_Experiments.tex:20、24）没有给出获取方式。 Neurocomputing 鼓励（虽不强制）代码开放；对一个以评估严谨性为卖点的论文， **不公开审计工件是不可接受的**。**要求**：投稿时提交代码 + 审计工件 （匿名仓库），Data availability 改为逐数据集的公开来源引用。

### 4.3 案例研究的证据边界

Case study 仅 1 个样本（sample 0）的 4 个窗口、且曲线经三次样条插值渲染 （5_Experiments.tex:113-124）。论文自己承认"illustrative rather than representative"（7_Conclusion.tex:18）。建议：(a) 扩至 ≥3 个样本或随机抽取窗口并报告选取规则； (b) 修正 H=384 与正文 horizon 集合的不一致；(c) 在图注中点名四个基线。 另外"gives the lowest window error on ... LUFL day-2"（5_Experiments.tex:122） 这类逐窗结论建议改为表格化数字（每窗 MSE），避免"文字判读"。

### 4.4 建议

**Major Revision**。科学内容上本文并无不可救药之处，但作为以"可诊断、 可审计"为卖点的投稿，其自身的工件审计链是断的——这在同等严谨性要求的 期刊（甚至 NeurIPS D&B track）都过不了关。修复是机械性的：重跑、快照、 索引、公开。

---

## 5. Reviewer 4 — Devil's Advocate 报告

### 5.1 最强反驳（strongest counter-argument）

> **这篇论文的两个卖点在当前证据下互相抵消。**
>
> 卖点 A 是架构："forecast-decomposable dual-domain" 框架带来精度收益。 但对同等调参基线（M2）和已发表数值（Electricity 0.174/0.169 vs S-Mamba published 0.176/0.170）的检验显示，收益主要产生于"自家逐数据集调参 vs 基线 固定默认"的不对称，且恰恰在最能检验变量 mixer 价值的 Traffic/PEMS04 上 输给 S-Mamba。**卖点 A 目前未被确立。**
>
> 卖点 B 是评估方法学：机制声明须过 BH 校正的确认性检验。但作者自己的 精确检验敏感性分析结论是"**No confirmatory core-ablation effect survives BH correction under the exact analysis**"（5_Experiments.tex:24）—— 6 seeds 下连 RevIN 都不显著。经得起论文自己最严格标准检验的机制结论 只剩下参数检验意义下的"RevIN 有效（ETTh2/Weather）+ 时间分支与 mixer 有效（仅 Weather）"，而 RevIN 是 2021 年的既有技术。**卖点 B 支持的 结论不是新的。**
>
> 于是剩下的是：新框架的收益未被确立，被确立的收益不属于新框架。 论文用"bounded, dataset-specific evidence"（7_Conclusion.tex:23）诚实地包装了这一现状——诚实值得肯定，但它同时意味着论文当前的形式 更接近一份高质量的**负结果/方法学报告**，而非 Neurocomputing 读者期待 的架构贡献。返修的方向只能是二选一：要么把架构收益做实（同等预算基线
>
> + 更多种子），要么把论文重定位为评估方法学贡献并相应重写贡献列表。

### 5.2 问题清单

| 级别         | 问题                                                                                                                                                                                                                                                                                                                                                                            | 位置                                                    |
| ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------- |
| **CRITICAL** | **摘要与正文证据等级直接冲突**：摘要称"four of these margins remain significant after Benjamini–Hochberg correction"与"Six-seed component analyses identify the mechanisms whose benefits are reproducible on specific datasets"（main.tex:68），而正文明确记录精确检验下**零**机制效应存活（5_Experiments.tex:24）。"identify mechanisms whose benefits are reproducible"是对参数检验子集的选择性上色——按论文自己的标准，reproducible 的机制一个都没有。highlights 第 3 条与贡献 (4) 同样未加参数检验限定 | main.tex:68 · highlights.tex:10 · 1_Intro.tex:15 vs 5_Experiments.tex:24 |
| **CRITICAL** | **Traffic 头条数值溯源断裂 + 论文/代码配置注释矛盾**（详见 Reviewer 3 R1）：论文声明最终配方为 d=256/shared，代码注释却指向相反配置（d=512/both，且引用稿件中不存在的表），表格各 horizon 在两个存储工件里各匹配一半。这不是表述问题，是**结果完整性问题**                                                                                                                               | 5_Experiments.tex:14 · traffic.yaml:24-29 · results/*.json |
| MAJOR        | **Solar 排除出确认族的时机**：Solar 被排除在"predeclared confirmatory families"外（5_Experiments.tex:24），而它恰是 RevIN-off 决策（见 Reviewer 1 M5）最不利的数据集；且 4 处逐字重复的免责声明是典型的"事后防御性补丁"形态                                                                                                                                                | 同 M5 所列 4 处 + 2 处表注转述                            |
| MAJOR        | **Cherry-picking 风险：Exchange 与 Traffic 的处理不对称**。"five of six datasets"的推断族恰好不含 Exchange（描述性结果中 \model{} 平均落后 FEDformer 0.354/iTransformer 0.360，table_horizons_general.tex:38）与 Solar；推断族选取标准（为何恰好是 6 个 ETT+Weather+Electricity）未在任何地方 predeclare                                                                                                           | 5_Experiments.tex:24、54                                 |
| MAJOR        | **"diagnosable"承诺 vs 诊断输出缺失**：框架最独特的诊断证据（gate 分布、branch-only 全景、correlation/dispersion 假设检验）全部缺席，实际展示的诊断仍是消融表——即论文批评的"aggregate score"文化的另一种形态                                                                                                                                                                    | 见 Reviewer 2 §3.2                                      |
| MINOR        | 贡献 (4) 中"five of six benchmarks"与"four margins surviving"并置，未标注后者为参数检验结论；highlights 第 3 条同                                                                                                                                                                                                                                                               | 1_Intro.tex:15 · highlights.tex:10                       |
| MINOR        | 案例研究窗口选取自陈"do not uniformly favor \model{}"（好），但单样本 + 插值渲染 + H=384 笔误三连使该节证据价值接近于零                                                                                                                                                                                                                                                         | 5_Experiments.tex:113-124                               |

### 5.3 被忽略的替代解释

1. **"增益来自容量而非双域结构"**：Weather 配置为 d=256 + 双路 + 解绑双 mixer（weather.yaml:41-49 注释：解绑 5.77M vs 共享 3.49M），参数量显著大于 rerun 基线。 在参数量对齐（如 S-Mamba 扩容 或 \model{} 缩容）前，"dual-domain 设计带来收益"与"容量带来收益"两个假设无法区分。**参数对齐消融缺失**。
2. **"收益来自 RevIN+调参的组合"**：消融显示 normalization 是最大效应 （5_Experiments.tex:76）；RLinear（RevIN+线性）在 ETTh2 平均 MSE 0.374 与 \model{} 并列 best（table_horizons_ett.tex:30）。一个"RLinear + mixer"的 中间控制实验即可检验 \model{} 的增量是否主要来自 Mamba/FITS 组件—— 该实验未做。
3. **"频域分支可以被删掉"**：消融矩阵内 ETTh2 上 Mean fusion 在全部 4 个 horizon 均优于 full（0.288/0.367/0.413/0.422 vs 0.293/0.370/0.416/0.425）， Solar 上 w/o FD branch 在 H≥192 更好（table_core_ablation_main.tex）。 "dual-domain"框架的**一半在三个消融数据集的两个上无法证明自己的存在必要**——标题中的"Dual-Domain"目前的实证支撑主要只剩 Weather 一个数据集。

### 5.4 "So what?" 检验

假设所有结论按参数检验版本成立：读者得到的是一个"在 6 个基准中的 5 个上 平均 MSE 略好、但内存最多贵数十倍、且需要逐数据集在 both/shared mixer、 FITS on/off、RevIN on/off、mamba/mlp 时间编码器之间做配置选择"的框架 ——而论文明确拒绝给出配置选择规则（"not a transferable selection rule"， 1_Intro.tex:15）。那么对读者而言，**本文当前交付的可用知识主要是 评估协议本身**。这个结论是诚实的，但应当成为重定位的依据而非被包裹在 架构论文的叙事里。

### 5.5 观察（非缺陷）

- 论文的威胁效度节（7_Conclusion.tex:17-18）是本审稿人近年见过最完整的， 包括对自身工件缺陷的承认——这份坦诚应在本刊被鼓励而非惩罚。
- 阴性结果（FITS 通道无均值收益、长 schedule 只降训练损失）的保留值得肯定。

---

## 6. 编辑综合决定（Editorial Decision）

### 6.1 审稿团共识与分歧

| 议题                     | A    | R1                 | R2              | R3            | R4                         | 结论                 |
| ------------------------ | ---- | ------------------ | --------------- | ------------- | -------------------------- | -------------------- |
| 评估协议是贡献           | ✓    | ✓（框架好）        | ✓               | ✓             | ✓（协议=论文现存主要价值） | **全票共识**         |
| 架构收益已确立           | 部分 | ✗（M2 预算不对等） | 部分            | ✗             | ✗                          | **多数反对**         |
| 摘要/结论证据等级需对齐  | ✓    | ✓                  | —               | —             | ✓（CRITICAL）              | **共识**             |
| Traffic/Solar 溯源需重建 | ✓    | ✓（M5）            | —               | ✓（CRITICAL） | ✓（CRITICAL）              | **共识（最高优先）** |
| 方法节深度不足           | —    | —                  | ✓（D2）         | —             | —                          | R2 独有视角          |
| 资源成本叙事需强化       | —    | m3                 | —               | ✓             | —                          | R3 主持              |
| 应重定位为方法学论文     | 倾向 | —                  | ✗（补实验可救） | —             | ✓                          | **分歧**→ 裁决见下   |

**裁决（分歧项）**：R2 的路线（补实验做实架构贡献）与 R4 的路线（重定位为 评估方法学）并非互斥。要求作者**先完成 P0/P1 的证据修复，再依据修复后的 结果自选叙事**——若参数/预算对齐后增益仍在，按架构论文收尾；若不存， 按方法学论文重写贡献列表与标题侧重。当前稿件以架构论文叙事提交而证据 不支持，这是主要风险而非两条路线本身。

### 6.2 决定信（致作者）

感谢您向 Neurocomputing 提交稿件。五位审稿人一致认为本文的评估方法学 （matched-seed 配对检验、BH 族校正、精确检验敏感性分析、同硬件效率协议） 显著高于本领域平均水准，威胁效度讨论的坦诚值得肯定。然而，稿件当前 **不能被接受**，需要一轮重大修改。决定性因素有三：

1. **结果完整性（CRITICAL）**：Traffic 头条数值（0.437）无法溯源到唯一 配置/工件：论文声明的最终配方（d=256/shared）与随稿代码的配置注释 （指向 d=512/both，且引用稿件中不存在的表）互相矛盾，表格各 horizon 与两个存储工件均只部分匹配；Solar 的 RevIN-off 决策证据与 "validation-only"声明存在矛盾迹象。在这些问题解决前，主表中任何 数字的可靠性都无法确认。
2. **证据等级不一致（CRITICAL）**：摘要/highlights/贡献 (4) 宣称"four margins survive BH""identify the mechanisms whose benefits are reproducible"而无参数检验限定，正文却记录精确检验下 零机制效应存活；"four margins survive BH"仅为 5 对样本下的参数检验 结论（精确检验在该样本量下数学上不可能显著）。
3. **架构增益未在公平条件下确立（MAJOR）**：推断性结论建立在基线固定默认 配置 vs 本文逐数据集调参的不对称上；对基线已发表值的优势基本消失； 参数量与 mixer placement 均未对齐。

请按第 6.3 节路线图逐项回复。**P0 项为返回送审的必要条件**；P1 项决定 论文最终以架构贡献还是评估方法学贡献定形。

### 6.3 Revision Roadmap（按优先级）

#### P0 — 返回送审的必要条件（CRITICAL）

| #    | 事项                                                                                                                                                                                                 | 涉审意见        | 验收标准                                        |
| ---- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------- | ----------------------------------------------- |
| P0-1 | **重建 Traffic（及 Electricity legacy 格子）结果**：以 immutable config snapshot 重跑全部 horizon、≥3 seeds，替换 Table 4 相关行；消除论文↔traffic.yaml 注释矛盾（含清理其对不存在表格的引用）                                                                        | R3-R1、R4-C2    | 每个单元格可映射到含 config hash + seeds 的工件 |
| P0-2 | **统一证据等级表述**：摘要、highlights 第 3 条、贡献 (4)、结论四处，将"significant/survive BH"限定为参数检验；如实注明精确检验结论；删除或改写"mechanisms whose benefits are reproducible"                                                                           | R4-C1、A        | 摘要↔highlights↔贡献↔结论无冲突表述             |
| P0-3 | **Solar 协议澄清**：提供 RevIN-off 决策的 validation-only 证据记录；解释 solar.yaml "ablation-verified −0.016 @96" 出处与 legacy 工件（full vs no_revin 差异 ~1e-4）的矛盾；4 处重复免责声明合并为 5.1 内一处                                                          | R1-M5、R4-Solar | 单一协议陈述 + 可验证记录                       |
| P0-4 | **公开工件**：匿名代码仓库 + machine-readable audit（42 对照与消融的种子级记录）+ 单元格→工件索引表；Data availability 改为逐数据集公开来源                                                                                                                          | R3-R3           | 补充材料可下载                                  |

#### P1 — 决定论文定形的实质性修改（MAJOR）

| #    | 事项                                                                                                    | 涉审意见              |
| ---- | ------------------------------------------------------------------------------------------------------- | --------------------- |
| P1-1 | 基线同等调参预算重跑（或官方实现/已发表值替代并统一降级为描述性），重点 S-Mamba/iTransformer/PatchTST   | R1-M2、R4             |
| P1-2 | 种子数提升：推断实验 ≥10 seeds（使 exact 检验可达 p<0.05）；主表/消融表/效率表统一种子协议并报 mean±std/CI | R1-M1/M3/M4           |
| P1-3 | 补 FITS 单独基线 + freq_only 全数据集 branch-only 表 + 门控值分布图                                     | R2-D1/D2、R4 诊断缺位 |
| P1-4 | 复杂度分析小节 + mixer placement 定义 + 门控初始化论证 + 公式去代码化                                   | R2-D2                 |
| P1-5 | Look-back 研究（L∈{96,336,512}，≥2 数据集）                                                             | R2                    |
| P1-6 | 参数量/容量对齐消融（\model{} 缩容 vs S-Mamba 扩容；RLinear+mixer 控制）                                | R4 替代解释 1/2       |
| P1-7 | 效率节补 inference latency + shared-placement 帕累托点 + 每 1% MSE 的资源成本表述                       | R3 §4.1               |
| P1-8 | Weather mixer 回退决策的验证集证据澄清                                                                  | R1-M6                 |

#### P2 — 表述与合规（MINOR）

1. Case study：H=384→336（或解释）、样本扩容/选取规则、图注点名基线、逐窗 MSE 表格化。
2. Table 1 补 PEMS 行。
3. 关键词 "Multivariate analysis"→"Multivariate time series"。
4. 贡献 (3) 兑现（correlation/dispersion 分析图表）或删除。
5. 作者/致谢占位符落实；Fig.1 图注与 AI 声明节去重。
6. R1 minors：Weather lr 网格补点（或删 Weather 的 lr 面板解读）、per-dataset BH 稳健性讨论、推理延迟补测。
7. Discussion 正面处理"mixer 启用数据集上输给 S-Mamba"的不对称。

### 6.4 复审清单（re-review 时逐项核对）

- [ ] Traffic/Electricity 每格 → 工件（config hash + seeds）映射表存在
- [ ] traffic.yaml 注释与论文一致（含清除对不存在表格的引用）
- [ ] 摘要/highlights/贡献(4)/结论四处证据等级措辞一致（参数检验限定）
- [ ] Solar 声明仅出现一次且有 validation 记录支撑
- [ ] exact 检验最小 p 值约束下重述的显著性结论
- [ ] 基线搜索预算记录（或官方数值降级声明）
- [ ] FITS 基线列 + freq_only 表 + gate 分布图
- [ ] 复杂度小节 + placement 定义
- [ ] look-back 实验
- [ ] latency/吞吐 + 帕累托点
- [ ] 公开仓库可访问

---

## 附录 A：论文 ↔ 代码核对证据表（内部审计用）

> 本附录汇总审稿过程中直接核对到的工件证据，供作者修复时定位。

| #   | 论文陈述                                                                                   | 代码/工件事实                                                                                                                                                        | 性质        |
| --- | ------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------- |
| A1  | Traffic 最终配方由 traffic.yaml 固定：d=256/shared，约 2.92M 参数（5_Experiments.tex:14）   | traffic.yaml:24-29 注释："512->256 cuts ~19.7M -> ~5.3M. NOTE: the manuscript's headline Traffic accuracy was measured at **d=512 with mixer_placement=both**; set both to reproduce Table 6 (see tab:hparams caption)"（tab:hparams 在稿件中不存在） | 直接矛盾    |
| A2  | Table 4 Traffic 行 0.401/0.423/0.441/0.481（table_pems_traffic.tex:19-24）                 | Main_traffic.json（3s，无 config 快照）= 0.402/0.424/0.441/0.485；reduced_traffic_d256.json（5s）= 0.401/0.423/0.444/0.480                                         | 混合来源    |
| A3  | Solar RevIN-off "based on validation-set performance"（4 处逐字 + 2 处表注转述）           | solar.yaml:37-39："ablation-verified: instance norm HURTS solar (−0.016 MSE @96)"；Ablation_solar_final.json：no_revin mean MSE 0.18022，与 full 差异 ~1e-4        | 证据矛盾    |
| A4  | Weather "two separate two-layer VC mixers per branch"（5_Experiments.tex:28）              | weather.yaml:41-49：placement both，注释明言自 shared 回退以防"erases the Weather margin over PatchTST"                                                              | 边缘选择性  |
| A5  | 方法节未定义 mixer placement（4_Method.tex:55-56）                                         | dual_domain_model.py:102-109 定义 both/time/freq/shared 四种                                                                                                         | 覆盖不足    |
| A6  | "machine-readable audit"（5_Experiments.tex:20、24）                                       | 未提供获取方式；results/ 内 20+ JSON 无索引                                                                                                                           | 可用性缺失  |
| A7  | case study H∈{96,192,384}（fig:case_study，5_Experiments.tex:116）                         | 全文协议 H∈{96,192,336,720}                                                                                                                                          | 笔误/未解释 |

## 附录 B：Neurocomputing 合规速查

| 项                                               | 状态                                             |
| ------------------------------------------------ | ------------------------------------------------ |
| 摘要 <250 词                                     | ✓（约 190 词）                                   |
| 关键词 =5                                        | ✓（建议替换 "Multivariate analysis"）            |
| Highlights 3–5 条 ≤85 字符                       | ✓（第 3 条需加参数检验限定，见 P0-2）            |
| 贡献 3–5 条 + roadmap                            | ✓（4 条）                                        |
| 表格无竖线/底纹、表注在下                        | ✓                                                |
| 引用数字编号按出现顺序                           | ✓（elsarticle-num）                              |
| CRediT / 资助 / AI 声明 / Data availability 块序 | ✓（作者与致谢占位待落实）                        |
| 双栏 LaTeX、图 PDF 矢量                          | ✓                                                |
| 生成式 AI 声明                                   | ✓（main.tex:100-101 + Fig.1 图注重复，建议去重） |

---

*本报告由 academic-paper-reviewer 五席评审流程生成，全部意见均锚定至稿件具体 位置或代码工件；合成阶段未新增任何未经分报告支撑的批评。*
